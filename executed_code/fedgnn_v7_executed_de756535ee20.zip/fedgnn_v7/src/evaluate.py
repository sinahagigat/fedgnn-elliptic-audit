# -*- coding: utf-8 -*-
"""
evaluate.py — ارزیابی مدل روی هر split دلخواه (val/test) — تک‌نقطهٔ حقیقت متریک‌ها
==============================================================================
تنها نقطه‌ای در کل پروژه که متریک‌های ارزیابی (AP, AUC, F1, Precision,
Recall, Confusion Matrix) محاسبه می‌شوند. هم client.py (برای val محلی هر
راند) و هم train.py (برای test سراسری نهایی) باید صرفاً از
evaluate_variant_on_global_test/evaluate_split استفاده کنند — هیچ فرمول
متریک نباید در جای دیگری بازنویسی شود.
"""

from __future__ import annotations

import logging
from typing import Dict, Optional

import numpy as np
import torch
import torch.nn.functional as F
from sklearn.metrics import (
    average_precision_score,
    roc_auc_score,
    f1_score,
    precision_score,
    recall_score,
    confusion_matrix,
    matthews_corrcoef,
    precision_recall_curve,
)
from src.compat import safe_forward

logger = logging.getLogger("fedgnn.evaluate")

# NOTE (state of the codebase, not an aspiration):
#   client.py currently computes val AP/AUC with sklearn directly. Those two
#   metrics are threshold-independent and use the identical sklearn calls, so
#   they are numerically identical to this module. Every THRESHOLD-DEPENDENT
#   metric reported in the paper (F1/Precision/Recall/MCC/CM) comes only from
#   evaluate_split below. Routing client.py through evaluate_split is pending.


# ==============================================================================
# ارزیابی روی یک mask دلخواه از یک شیء Data واحد
# ==============================================================================
@torch.no_grad()
def evaluate_split(
    model: torch.nn.Module,
    x: torch.Tensor,
    edge_index: torch.Tensor,
    y: torch.Tensor,
    mask: torch.Tensor,
    device: str,
    boundary_idx: Optional[torch.Tensor] = None,
    threshold: Optional[float] = None,
) -> Dict[str, float]:
    """
    محاسبهٔ کامل متریک‌های استاندارد طبقه‌بندی دوکلاسه روی زیرمجموعهٔ mask.

    نکات صداقت علمی:
      - اگر mask هیچ نمونهٔ مثبتی نداشته باشد، AP/AUC عملاً بی‌معنی‌اند؛
        در این حالت به‌جای اسکیپ کردن silent، مقدار NaN برگردانده می‌شود
        و مسئولیت مدیریت آن به caller سپرده می‌شود (Fail-fast نیمه — نه
        کرش کامل، اما هم پنهان‌کاری هم نمی‌شود).
      - آستانهٔ طبقه‌بندی سخت (برای F1/Precision/Recall) argmax روی
        logits دوبعدی است — نه یک آستانهٔ دلخواه روی احتمال کلاس ۱.
    """
    model.eval()
    node_emb, logits = safe_forward(model, x, edge_index, boundary_idx)

    y_masked = y[mask].cpu().numpy()
    logits_masked = logits[mask]

    probs = F.softmax(logits_masked, dim=-1)[:, 1].cpu().numpy()

    if threshold is None:
        # رفتار تاریخی: argmax روی دو logit ≡ آستانهٔ ۰٫۵ روی p(y=1)
        # (تفاوت تنها در تساوی دقیق است که رخدادش اندازه-صفر است)
        preds = logits_masked.argmax(dim=-1).cpu().numpy()
        thr_used = 0.5
    else:
        thr_used = float(threshold)
        preds = (probs >= thr_used).astype(np.int64)

    n_pos = int((y_masked == 1).sum())
    n_total = len(y_masked)

    if n_pos == 0 or n_pos == n_total:
        logger.warning(
            f"⚠️ evaluate_split: mask با {n_total} نمونه فقط یک کلاس دارد "
            f"(n_pos={n_pos}) — AP/AUC به NaN تنظیم می‌شود."
        )
        ap, auc = float("nan"), float("nan")
    else:
        ap = float(average_precision_score(y_masked, probs))
        auc = float(roc_auc_score(y_masked, probs))

    f1 = float(f1_score(y_masked, preds, zero_division=0))
    precision = float(precision_score(y_masked, preds, zero_division=0))
    recall = float(recall_score(y_masked, preds, zero_division=0))
    try:
        mcc = float(matthews_corrcoef(y_masked, preds))
    except Exception:
        mcc = 0.0

    cm = confusion_matrix(y_masked, preds, labels=[0, 1])
    tn, fp, fn, tp = cm.ravel() if cm.size == 4 else (0, 0, 0, 0)

    return {
        "ap": ap,
        "auc": auc,
        "f1": f1,
        "precision": precision,
        "recall": recall,
        "mcc": mcc,
        "threshold": float(thr_used),
        "n_samples": n_total,
        "n_positive": n_pos,
        "confusion_matrix": {"tn": int(tn), "fp": int(fp), "fn": int(fn), "tp": int(tp)},
    }


# ==============================================================================
# v7: metrics from a score vector (used by per-client inference, where scores
# from several client subgraphs are concatenated before computing metrics)
# ==============================================================================
@torch.no_grad()
def predict_scores(model, x, edge_index, boundary_idx=None) -> np.ndarray:
    """p(y=1) for every node of one graph, model in eval mode."""
    model.eval()
    _, logits = safe_forward(model, x, edge_index, boundary_idx)
    return F.softmax(logits, dim=-1)[:, 1].detach().cpu().numpy()


def metrics_from_scores(
    y_true: np.ndarray, probs: np.ndarray, threshold: Optional[float] = None
) -> Dict[str, float]:
    """
    Same metric set as evaluate_split, computed from scores.
    threshold=None reproduces evaluate_split's default rule exactly:
    argmax over two logits picks class 1 iff p(y=1) > 0.5 (ties go to class 0).
    """
    y_true = np.asarray(y_true).astype(np.int64).ravel()
    probs = np.asarray(probs, dtype=np.float64).ravel()
    if threshold is None:
        preds = (probs > 0.5).astype(np.int64)
        thr_used = 0.5
    else:
        thr_used = float(threshold)
        preds = (probs >= thr_used).astype(np.int64)
    n_pos = int((y_true == 1).sum())
    n_total = int(y_true.size)
    if n_pos == 0 or n_pos == n_total:
        ap, auc = float("nan"), float("nan")
    else:
        ap = float(average_precision_score(y_true, probs))
        auc = float(roc_auc_score(y_true, probs))
    cm = confusion_matrix(y_true, preds, labels=[0, 1])
    tn, fp, fn, tp = cm.ravel() if cm.size == 4 else (0, 0, 0, 0)
    try:
        mcc = float(matthews_corrcoef(y_true, preds))
    except Exception:
        mcc = 0.0
    return {
        "ap": ap,
        "auc": auc,
        "f1": float(f1_score(y_true, preds, zero_division=0)),
        "precision": float(precision_score(y_true, preds, zero_division=0)),
        "recall": float(recall_score(y_true, preds, zero_division=0)),
        "mcc": mcc,
        "threshold": float(thr_used),
        "n_samples": n_total,
        "n_positive": n_pos,
        "confusion_matrix": {"tn": int(tn), "fp": int(fp), "fn": int(fn), "tp": int(tp)},
    }


def tuned_metrics_from_scores(
    y_val: np.ndarray, p_val: np.ndarray, y_test: np.ndarray, p_test: np.ndarray
) -> Dict[str, float]:
    """Threshold chosen on validation (max F1), then applied once to test."""
    sel = find_best_threshold(y_val, p_val, metric="f1")
    out = metrics_from_scores(y_test, p_test, threshold=sel["threshold"])
    out["threshold_source"] = "val"
    out["val_tuned_f1"] = float(sel["score"])
    return out


# ==============================================================================
# Wrapper راحت برای ارزیابی نهایی test سراسری (استفاده در train.py)
# ==============================================================================
@torch.no_grad()
def evaluate_variant_on_global_test(
    model: torch.nn.Module,
    data,
    mask: torch.Tensor,
    device: str,
) -> Dict[str, float]:
    """
    Wrapper نازک روی evaluate_split برای ارزیابی مدل global بهینه‌شده روی
    مجموعهٔ test سراسری (بدون تقسیم کلاینتی) — تنها مسیری که در train.py
    برای گزارش نهایی مقاله استفاده می‌شود (تک‌نقطهٔ حقیقت ارزیابی نهایی).
    """
    boundary_idx = getattr(data, "boundary_idx", None)
    return evaluate_split(
        model=model,
        x=data.x,
        edge_index=data.edge_index,
        y=data.y,
        mask=mask,
        device=device,
        boundary_idx=boundary_idx,
    )


# ==============================================================================
# انتخاب آستانه روی val (هرگز روی test) — P0-2
# ==============================================================================
def find_best_threshold(
    y_true: np.ndarray,
    probs: np.ndarray,
    metric: str = "f1",
) -> Dict[str, float]:
    """
    آستانهٔ بهینه‌کنندهٔ F1 (کلاس مثبت) روی یک split — با جست‌وجوی دقیق.

    چرا precision_recall_curve و نه گرید یکنواخت؟ چون F1 به‌عنوان تابعی از
    آستانه، پله‌ای است و فقط در نقاط امتیازِ مشاهده‌شده تغییر می‌کند؛ پس
    بیشینهٔ سراسری قطعاً روی یکی از همین نقاط است. گرید یکنواخت هم کندتر
    است هم می‌تواند بیشینه را رد کند (نه تقریب، بلکه جست‌وجوی کامل).

    قاعدهٔ تساوی: در صورت F1 برابر، بزرگ‌ترین آستانه انتخاب می‌شود (precision
    بالاتر، FP کمتر) — قاعده‌ای قطعی و بازتولیدپذیر، نه انتخاب دلبخواه.
    """
    if metric != "f1":
        raise NotImplementedError(f"[evaluate] metric پشتیبانی‌نشده: {metric}")

    y_true = np.asarray(y_true).astype(np.int64).ravel()
    probs = np.asarray(probs, dtype=np.float64).ravel()
    if y_true.shape != probs.shape:
        raise ValueError(f"[evaluate] ناسازگاری شکل: {y_true.shape} vs {probs.shape}")

    n_pos = int((y_true == 1).sum())
    if n_pos == 0 or n_pos == y_true.size:
        logger.warning(
            "⚠️ find_best_threshold: split تیون تک‌کلاسه است — "
            "بازگشت به آستانهٔ پیش‌فرض ۰٫۵ (بدون کالیبراسیون)."
        )
        return {"threshold": 0.5, "score": float("nan"), "n_candidates": 0}

    prec, rec, thr = precision_recall_curve(y_true, probs)
    prec, rec = prec[:-1], rec[:-1]          # آخرین نقطه آستانهٔ متناظر ندارد
    denom = prec + rec
    f1 = np.where(denom > 0.0, 2.0 * prec * rec / np.maximum(denom, 1e-12), 0.0)

    best = f1.max()
    cand = np.flatnonzero(f1 >= best - 1e-12)
    i = int(cand[np.argmax(thr[cand])])
    return {
        "threshold": float(thr[i]),
        "score": float(f1[i]),
        "n_candidates": int(thr.size),
    }


@torch.no_grad()
def evaluate_variant_on_global_test_tuned(
    model: torch.nn.Module,
    data,
    val_mask: torch.Tensor,
    test_mask: torch.Tensor,
    device: str,
    metric: str = "f1",
) -> Dict[str, float]:
    """
    ارزیابی نهایی test با آستانهٔ کالیبره‌شده روی val.

    ترتیب اکید عملیات (جلوگیری از نشت اطلاعات):
      ۱) استخراج p(y=1) فقط روی val_mask
      ۲) یافتن τ* روی همان val
      ۳) اعمال τ* روی test — test هرگز در تعیین τ* دخالتی ندارد

    خروجی هم متریک‌های τ* و هم متریک‌های آستانهٔ ۰٫۵ را نگه می‌دارد تا
    گزارش قابل حسابرسی باشد و تیون‌شدن روی test قابل رد کردن باشد.
    AP/AUC مستقل از آستانه‌اند و در هر دو حالت یکسان می‌مانند.
    """
    boundary_idx = getattr(data, "boundary_idx", None)
    model.eval()
    _, logits = safe_forward(model, data.x, data.edge_index, boundary_idx)

    probs_val = F.softmax(logits[val_mask], dim=-1)[:, 1].cpu().numpy()
    y_val = data.y[val_mask].cpu().numpy()
    sel = find_best_threshold(y_val, probs_val, metric=metric)
    tau = float(sel["threshold"])

    common = dict(
        model=model, x=data.x, edge_index=data.edge_index, y=data.y,
        mask=test_mask, device=device, boundary_idx=boundary_idx,
    )
    m_def = evaluate_split(threshold=None, **common)
    out = dict(evaluate_split(threshold=tau, **common))

    out["threshold_source"] = "val"
    out["threshold_metric"] = metric
    out["val_tuned_score"] = float(sel["score"])
    out["n_threshold_candidates"] = int(sel["n_candidates"])
    for k in ("f1", "precision", "recall", "mcc"):
        out[f"{k}_at_default"] = float(m_def[k])
    out["confusion_matrix_at_default"] = m_def["confusion_matrix"]

    logger.info(
        f"🎯 آستانه از val: τ*={tau:.4f} (val_F1={sel['score']:.4f}) | "
        f"test_F1: {m_def['f1']:.4f} @0.5 → {out['f1']:.4f} @τ* | "
        f"P={out['precision']:.4f} R={out['recall']:.4f} MCC={out['mcc']:.4f} | "
        f"AP={out['ap']:.4f} (بدون تغییر)"
    )
    return out
