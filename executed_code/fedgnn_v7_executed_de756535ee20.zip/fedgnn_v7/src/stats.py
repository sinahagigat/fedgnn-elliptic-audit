# -*- coding: utf-8 -*-
"""
stats.py — لایهٔ آزمون‌های آماری (تک‌نقطهٔ حقیقت مقایسهٔ واریانت‌ها)
==============================================================================
هدف: هیچ فرمول آماری (Holm-Bonferroni، TOST، Wilcoxon، Cohen's d) نباید در
analyze.py یا جای دیگری به‌صورت inline بازنویسی شود.

⚠️ صداقت آماری حیاتی برای داور Q2: با فقط ۳ seed در هر واریانت، توان
آماری (statistical power) آزمون‌های پارامتریک بسیار محدود است. این ماژول
هم t-test زوجی و هم Wilcoxon ناپارامتری را فراهم می‌کند، اما در خروجی هر
دو، صراحتاً هشدار n=3 را برمی‌گرداند. در مقاله این آزمون‌ها باید به‌عنوان
«شاخص جهت اثر» (signal) معرفی شوند، نه اثبات قطعی برتری — ادعای معناداری
آماری قوی با n=3 توسط هر داور Q2 رد می‌شود و صداقت این محدودیت، خودش یک
امتیاز مثبت در بخش Limitations است.
"""

from __future__ import annotations

import logging
import math
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence

import numpy as np
from scipy import stats as scipy_stats

logger = logging.getLogger("fedgnn.stats")

MIN_RECOMMENDED_N = 5  # زیر این تعداد seed، هشدار توان آماری صادر می‌شود


# ==============================================================================
# اندازهٔ اثر — Cohen's d برای نمونه‌های زوجی
# ==============================================================================
def cohens_d_paired(a: Sequence[float], b: Sequence[float]) -> float:
    """
    اندازهٔ اثر استاندارد برای نمونه‌های زوجی: d = mean(diff) / std(diff).
    این مقدار مستقل از n است و حتی با n=3 قابل گزارش و تفسیر کیفی
    (کوچک/متوسط/بزرگ طبق قرارداد Cohen 1988) است — برخلاف p-value که با
    n کوچک بی‌ثبات می‌شود.
    """
    a_arr, b_arr = np.asarray(a, dtype=float), np.asarray(b, dtype=float)
    assert a_arr.shape == b_arr.shape, "❌ cohens_d_paired: طول دو نمونه باید برابر باشد."
    diff = a_arr - b_arr
    std_diff = float(np.std(diff, ddof=1)) if len(diff) > 1 else 0.0
    if std_diff == 0.0:
        return 0.0 if float(np.mean(diff)) == 0.0 else float("inf")
    return float(np.mean(diff) / std_diff)


def interpret_cohens_d(d: float) -> str:
    """تفسیر کیفی طبق قرارداد استاندارد Cohen (1988) — صرفاً راهنمای گزارش‌دهی."""
    ad = abs(d)
    if ad < 0.2:
        return "negligible"
    elif ad < 0.5:
        return "small"
    elif ad < 0.8:
        return "medium"
    else:
        return "large"


# ==============================================================================
# مقایسهٔ زوجی — t-test پارامتریک + Wilcoxon ناپارامتریک، هر دو با هم
# ==============================================================================
@dataclass
class PairwiseComparisonResult:
    metric_name: str
    variant_a: str
    variant_b: str
    n_seeds: int
    mean_a: float
    mean_b: float
    mean_diff: float
    t_stat: float
    t_pvalue: float
    wilcoxon_stat: Optional[float]
    wilcoxon_pvalue: Optional[float]
    cohens_d: float
    effect_size_label: str
    low_power_warning: bool
    note: str = ""


def paired_comparison(
    scores_a: Sequence[float],
    scores_b: Sequence[float],
    variant_a: str,
    variant_b: str,
    metric_name: str,
) -> PairwiseComparisonResult:
    """
    مقایسهٔ زوجی کامل بین دو واریانت روی همان مجموعه seedها. Wilcoxon فقط
    وقتی n>=6 محاسبه می‌شود (زیر این آستانه، جدول p-value دقیق Wilcoxon
    غیرقابل‌اعتماد است)، در غیر این‌صورت None برمی‌گردد و caller باید فقط
    به Cohen's d و میانگین تکیه کند.
    """
    a_arr, b_arr = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    assert a_arr.shape == b_arr.shape, "❌ paired_comparison: طول دو بردار امتیاز برابر نیست."
    n = len(a_arr)
    assert n >= 2, "❌ paired_comparison: حداقل ۲ seed برای هر آزمون زوجی لازم است."

    t_stat, t_pvalue = scipy_stats.ttest_rel(a_arr, b_arr)

    wilcoxon_stat, wilcoxon_pvalue = None, None
    if n >= 6:
        try:
            wilcoxon_stat, wilcoxon_pvalue = scipy_stats.wilcoxon(a_arr, b_arr)
        except ValueError as exc:
            logger.warning(f"⚠️ Wilcoxon قابل‌محاسبه نبود ({variant_a} vs {variant_b}): {exc}")

    d = cohens_d_paired(a_arr, b_arr)
    low_power = n < MIN_RECOMMENDED_N
    note = (
        f"⚠️ n={n} seed — توان آماری محدود؛ p-value باید صرفاً به‌عنوان "
        f"شاخص جهت اثر تفسیر شود، نه اثبات قطعی برتری."
        if low_power else ""
    )

    return PairwiseComparisonResult(
        metric_name=metric_name,
        variant_a=variant_a,
        variant_b=variant_b,
        n_seeds=n,
        mean_a=float(np.mean(a_arr)),
        mean_b=float(np.mean(b_arr)),
        mean_diff=float(np.mean(a_arr) - np.mean(b_arr)),
        t_stat=float(t_stat),
        t_pvalue=float(t_pvalue),
        wilcoxon_stat=float(wilcoxon_stat) if wilcoxon_stat is not None else None,
        wilcoxon_pvalue=float(wilcoxon_pvalue) if wilcoxon_pvalue is not None else None,
        cohens_d=d,
        effect_size_label=interpret_cohens_d(d),
        low_power_warning=low_power,
        note=note,
    )


# ==============================================================================
# تصحیح مقایسهٔ چندگانه — Holm-Bonferroni (گام‌به‌گام، محافظه‌کارانه‌تر از Bonferroni ساده)
# ==============================================================================
@dataclass
class HolmCorrectionResult:
    original_pvalues: List[float]
    sorted_indices: List[int]
    adjusted_pvalues: List[float]
    reject_null: List[bool]
    alpha: float


def holm_bonferroni_correction(
    p_values: Sequence[float], alpha: float = 0.05
) -> HolmCorrectionResult:
    """
    تصحیح Holm-Bonferroni: p-valueهای مرتب‌شده صعودی، هرکدام با آستانهٔ
    alpha/(m-i) مقایسه می‌شوند (i اندیس صفرمبنا در ترتیب مرتب‌شده، m تعداد
    کل مقایسه‌ها). این روش نسبت به Bonferroni ساده (alpha/m برای همه) توان
    آماری بیشتری دارد و همچنان کنترل خطای نوع اول خانوادگی (FWER) را
    تضمین می‌کند — انتخاب استاندارد و قابل‌دفاع جلوی داور Q2.

    قاعدهٔ توقف: به محض برخورد با اولین p-value غیرمعنادار در ترتیب صعودی،
    همهٔ p-valueهای بعدی هم (حتی اگر عدد خامشان کوچک باشد) رد نمی‌شوند —
    این دقیقاً رفتار صحیح الگوریتم Holm است.
    """
    m = len(p_values)
    assert m >= 1, "❌ holm_bonferroni_correction: حداقل یک p-value لازم است."

    indexed = sorted(enumerate(p_values), key=lambda x: x[1])
    sorted_indices = [idx for idx, _ in indexed]
    sorted_pvals = [p for _, p in indexed]

    adjusted = [0.0] * m
    reject = [False] * m
    stop = False
    for rank, p in enumerate(sorted_pvals):
        threshold = alpha / (m - rank)
        adjusted[rank] = min(p * (m - rank), 1.0)  # آمار تعدیل‌شدهٔ گزارش‌پذیر
        if not stop and p <= threshold:
            reject[rank] = True
        else:
            stop = True  # از این نقطه به بعد، همه رد نمی‌شوند (رفتار صحیح Holm)

    # بازگرداندن به ترتیب اصلی ورودی
    final_adjusted = [0.0] * m
    final_reject = [False] * m
    for rank, orig_idx in enumerate(sorted_indices):
        final_adjusted[orig_idx] = adjusted[rank]
        final_reject[orig_idx] = reject[rank]

    return HolmCorrectionResult(
        original_pvalues=list(p_values),
        sorted_indices=sorted_indices,
        adjusted_pvalues=final_adjusted,
        reject_null=final_reject,
        alpha=alpha,
    )


# ==============================================================================
# TOST — آزمون هم‌ارزی (equivalence) دو یک‌طرفه؛ برای اثبات "تفاوت معنادار نیست"
# ==============================================================================
@dataclass
class TOSTResult:
    mean_diff: float
    lower_bound: float
    upper_bound: float
    p_lower: float
    p_upper: float
    p_tost: float
    equivalent: bool
    alpha: float
    n: int
    note: str = ""


def tost_equivalence_test(
    scores_a: Sequence[float],
    scores_b: Sequence[float],
    equivalence_margin: float,
    alpha: float = 0.05,
) -> TOSTResult:
    """
    Two One-Sided Tests (TOST) — کاربرد در این پروژه: اثبات این‌که عملکرد
    یک واریانت سبک‌تر (مثلاً FedGNN_SoftSelective بدون گره مجازی) از نظر
    عملی تفاوت معناداری با نسخهٔ کامل ندارد (هم‌ارزی)، نه فقط "تفاوت
    آماری معنادار پیدا نشد" (که اثبات هم‌ارزی نیست — یک خلط مفهومی رایج).

    منطق: H0_lower: mean_diff <= -margin   (رد شود ⇒ اختلاف پایین‌تر از
           مرز پایین نیست)
          H0_upper: mean_diff >= +margin   (رد شود ⇒ اختلاف بالاتر از
           مرز بالا نیست)
    اگر هر دو H0 رد شوند ⇒ هم‌ارزی در بازهٔ [-margin, +margin] پذیرفته
    می‌شود؛ p_tost = max(p_lower, p_upper) طبق قاعدهٔ استاندارد TOST.
    """
    a_arr, b_arr = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    diff = a_arr - b_arr
    n = len(diff)
    assert n >= 2, "❌ tost_equivalence_test: حداقل ۲ seed لازم است."
    assert equivalence_margin > 0, "❌ tost_equivalence_test: margin باید مثبت باشد."

    mean_diff = float(np.mean(diff))
    std_diff = float(np.std(diff, ddof=1)) if n > 1 else 1e-12
    se = std_diff / math.sqrt(n) if std_diff > 0 else 1e-12
    df = n - 1

    t_lower = (mean_diff - (-equivalence_margin)) / se
    p_lower = 1.0 - scipy_stats.t.cdf(t_lower, df)

    t_upper = (mean_diff - equivalence_margin) / se
    p_upper = scipy_stats.t.cdf(t_upper, df)

    p_tost = max(p_lower, p_upper)
    equivalent = p_tost < alpha

    note = (
        f"⚠️ n={n} seed — نتیجهٔ TOST با نمونهٔ کوچک باید محتاطانه تفسیر "
        f"شود؛ margin={equivalence_margin} به‌صورت دستی و مبتنی بر "
        f"اهمیت عملی (نه آماری) انتخاب شده است."
    )

    return TOSTResult(
        mean_diff=mean_diff, lower_bound=-equivalence_margin, upper_bound=equivalence_margin,
        p_lower=float(p_lower), p_upper=float(p_upper), p_tost=float(p_tost),
        equivalent=equivalent, alpha=alpha, n=n, note=note,
    )


# ==============================================================================
# ارکستریتور سطح بالا — همهٔ مقایسه‌های زوجی یک متریک با تصحیح Holm یک‌جا
# ==============================================================================
def compare_all_variants_vs_baseline(
    variant_scores: Dict[str, List[float]],
    baseline_name: str,
    metric_name: str,
    alpha: float = 0.05,
) -> Dict[str, object]:
    """
    مقایسهٔ همهٔ واریانت‌ها در برابر یک baseline مشخص (مثلاً FedAvg_GCN)،
    با اعمال تصحیح Holm-Bonferroni روی کل خانوادهٔ مقایسه‌ها (نه هر
    مقایسه به‌تنهایی) — این دقیقاً همان چیزی است که یک داور Q2 برای بخش
    "Statistical Significance" مقاله انتظار دارد.
    """
    assert baseline_name in variant_scores, f"❌ baseline '{baseline_name}' در variant_scores نیست."
    baseline_scores = variant_scores[baseline_name]

    comparisons: List[PairwiseComparisonResult] = []
    other_variants = [v for v in variant_scores if v != baseline_name]
    for variant_name in other_variants:
        result = paired_comparison(
            variant_scores[variant_name], baseline_scores, variant_name, baseline_name, metric_name
        )
        comparisons.append(result)

    holm = holm_bonferroni_correction(
        [c.t_pvalue for c in comparisons], alpha=alpha
    )

    return {
        "baseline": baseline_name,
        "metric": metric_name,
        "comparisons": comparisons,
        "holm_correction": holm,
        "significant_after_holm": [
            other_variants[i] for i, rej in enumerate(holm.reject_null) if rej
        ],
    }
