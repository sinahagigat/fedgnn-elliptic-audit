# -*- coding: utf-8 -*-
"""
seed.py — جبر کامل بازتولیدپذیری (Determinism)
================================================
تنظیم یکجای seed برای random، numpy، torch (CPU/GPU) و PyTorch Geometric.
بدون این ماژول، حتی با هش پیکربندی یکسان، دو ران می‌توانند نتایج متفاوت
بدهند و ادعای «بازتولیدپذیری کامل» در مقاله زیر سؤال می‌رود.
"""

from __future__ import annotations

import os
import random
from typing import Optional

import numpy as np
import torch


def set_global_seed(seed: int, deterministic_algorithms: bool = True) -> None:
    """
    تثبیت seed در تمام لایه‌های تصادفی‌سازی.

    Args:
        seed: مقدار seed.
        deterministic_algorithms: اگر True باشد، الگوریتم‌های غیرقطعی CUDA
            (مثل برخی scatter/gather در PyG) غیرفعال می‌شوند. این کار ممکن
            است اجرا را ۵-۱۵٪ کندتر کند اما بازتولیدپذیری را تضمین می‌کند.
    """
    os.environ["PYTHONHASHSEED"] = str(seed)
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)

    if deterministic_algorithms:
        os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
        torch.use_deterministic_algorithms(True, warn_only=True)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
    else:
        torch.backends.cudnn.deterministic = False
        torch.backends.cudnn.benchmark = True


def get_torch_generator(seed: int) -> torch.Generator:
    """یک torch.Generator مستقل برای DataLoader/Sampler با seed مشخص."""
    g = torch.Generator()
    g.manual_seed(seed)
    return g


def worker_init_fn(worker_id: int, base_seed: Optional[int] = None) -> None:
    """برای DataLoader(num_workers>0) — هر worker seed مستقل و قطعی بگیرد."""
    seed = (base_seed if base_seed is not None else torch.initial_seed()) + worker_id
    np.random.seed(seed % (2**32 - 1))
    random.seed(seed)
