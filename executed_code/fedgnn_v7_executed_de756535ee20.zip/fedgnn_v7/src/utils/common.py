# -*- coding: utf-8 -*-
"""
common.py — توابع کمکی مشترک کل پروژه (تک‌نقطهٔ حقیقت seed/I/O اتمیک/زمان)
==============================================================================
هر تابعی که در بیش از یک ماژول لازم است (تنظیم seed، خواندن/نوشتن اتمیک
JSON، گرفتن commit hash، ساخت کلید یکتای هر ران) اینجا تعریف می‌شود.
train.py، main.py و analyze.py همگی از همین‌ها استفاده می‌کنند.
"""

from __future__ import annotations

import json
import logging
import os
import random
import subprocess
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional

import numpy as np
import torch

logger = logging.getLogger("fedgnn.utils.common")


# ==============================================================================
# بازتولیدپذیری کامل — تک‌نقطهٔ حقیقت seed برای همهٔ منابع تصادفی
# ==============================================================================
def set_global_seed(seed: int, deterministic: bool = False) -> None:
    """
    Seed every RNG (random, numpy, torch CPU and CUDA).

    v7: with deterministic=True, torch.use_deterministic_algorithms(True) is
    also enabled. Without it, CUDA scatter/index_add kernels used by PyG
    message passing are non-deterministic, so two runs with the same seed can
    differ (the v6a runs measured up to 0.0057 AP between FedAvg and FedProx,
    which are mathematically identical with one local step).
    CUBLAS_WORKSPACE_CONFIG must be set before CUDA initialises; main.py does
    that at import time. warn_only=True means an op without a deterministic
    kernel emits a warning instead of crashing; the determinism check in the
    notebook verifies the outcome empirically.
    """
    assert isinstance(seed, int) and seed >= 0, f"invalid seed: {seed}"
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    if deterministic:
        os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
        torch.use_deterministic_algorithms(True, warn_only=True)
    logger.debug(f"seed={seed} set (deterministic={deterministic})")


def code_fingerprint(root: Optional[Path] = None) -> str:
    """
    SHA-256 over the contents of every .py file under src/ plus main.py,
    in sorted path order. Stored in every run record, so the exact code
    that produced a result can be identified later even without git.
    """
    import hashlib
    root = Path(root) if root else Path(__file__).resolve().parents[2]
    files = sorted(list((root / "src").rglob("*.py")) + [root / "main.py"])
    h = hashlib.sha256()
    for f in files:
        if f.exists() and "__pycache__" not in f.parts:
            h.update(str(f.relative_to(root)).replace("\\", "/").encode("utf-8"))
            h.update(f.read_bytes())
    return h.hexdigest()[:12]


def environment_info() -> Dict[str, Any]:
    """Library versions and hardware, stored with every run record."""
    import platform
    info: Dict[str, Any] = {
        "python": platform.python_version(),
        "torch": torch.__version__,
        "cuda_available": bool(torch.cuda.is_available()),
        "deterministic_algorithms": bool(torch.are_deterministic_algorithms_enabled()),
    }
    try:
        import torch_geometric
        info["torch_geometric"] = torch_geometric.__version__
    except Exception:
        pass
    if torch.cuda.is_available():
        info["cuda"] = torch.version.cuda
        info["gpu"] = torch.cuda.get_device_name(0)
    else:
        info["cpu"] = platform.processor() or platform.machine()
    return info


# ==============================================================================
# زمان و شناسهٔ ران
# ==============================================================================
def utc_timestamp() -> str:
    """timestamp استاندارد ISO-8601 با timezone UTC — بدون ابهام ناحیهٔ زمانی."""
    return datetime.now(timezone.utc).isoformat()


def make_run_key(variant_name: str, seed: int) -> str:
    """کلید یکتای هر (واریانت, seed) — برای ایندکس‌گذاری در artifacts.json."""
    assert variant_name, "❌ make_run_key: variant_name خالی است."
    return f"{variant_name}__seed{seed}"


# ==============================================================================
# اطلاعات نسخه — commit hash برای بازتولیدپذیری دقیق کد
# ==============================================================================
def get_git_commit_hash() -> Optional[str]:
    """
    گرفتن commit hash فعلی گیت (اگر پروژه در یک ریپازیتوری گیت باشد). در
    Colab معمولاً ریپازیتوری گیت وجود ندارد — در آن صورت Graceful
    Degradation: به‌جای کرش، None برمی‌گردد و در artifact ثبت می‌شود که
    "git_commit": null، نه یک خطا که کل ران را متوقف کند.
    """
    try:
        result = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            capture_output=True, text=True, timeout=5, check=True,
        )
        return result.stdout.strip()
    except (subprocess.CalledProcessError, FileNotFoundError, subprocess.TimeoutExpired):
        logger.debug("ℹ️ git commit hash در دسترس نیست (احتمالاً محیط Colab بدون git repo).")
        return None


# ==============================================================================
# I/O اتمیک برای JSON — جلوگیری از خراب‌شدن فایل در صورت قطع ناگهانی Colab
# ==============================================================================
def load_json_if_exists(path: Path, default: Dict[str, Any]) -> Dict[str, Any]:
    """
    اگر فایل وجود داشته باشد، محتوایش را برمی‌گرداند (پایهٔ Resume-by-default)؛
    در غیر این‌صورت، مقدار default (بدون نوشتن فایل جدید در همین لحظه).
    """
    path = Path(path)
    if not path.exists():
        logger.info(f"ℹ️ فایل {path} وجود ندارد — با حالت پیش‌فرض شروع می‌شود.")
        return default
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except json.JSONDecodeError as exc:
        logger.error(
            f"❌ فایل {path} خراب/ناقص است ({exc}) — به‌جای کرش کامل پروژه، "
            f"یک نسخهٔ پشتیبان {path}.corrupted می‌سازیم و از حالت پیش‌فرض ادامه می‌دهیم."
        )
        path.rename(path.with_suffix(path.suffix + ".corrupted"))
        return default


def atomic_save_json(path: Path, data: Dict[str, Any]) -> None:
    """
    نوشتن اتمیک JSON: ابتدا در یک فایل موقت در همان دایرکتوری نوشته می‌شود،
    سپس با os.replace (اتمیک در POSIX/NTFS) جای‌گزین فایل اصلی می‌شود. این
    یعنی حتی اگر Colab دقیقاً وسط نوشتن قطع شود، فایل اصلی artifacts.json
    هرگز نصفه/خراب نمی‌ماند — یا نسخهٔ قبلی کامل باقی می‌ماند یا نسخهٔ جدید
    کامل جایگزین می‌شود.
    """
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)

    fd, tmp_path = tempfile.mkstemp(dir=str(path.parent), suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2, default=str)
        os.replace(tmp_path, path)  # اتمیک — نه copy+delete
    except Exception:
        if os.path.exists(tmp_path):
            os.remove(tmp_path)
        raise


def ensure_dir(path: Path) -> Path:
    """ساخت دایرکتوری (با parents) اگر وجود نداشته باشد — idempotent."""
    path = Path(path)
    path.mkdir(parents=True, exist_ok=True)
    return path
