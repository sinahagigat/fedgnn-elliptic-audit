# -*- coding: utf-8 -*-
"""
io_utils.py — نوشتن اتمیک + Checkpoint/Resume
================================================
هدف: کرش در ران ۱۷ از ۱۸ نباید شما را به ران ۱ برگرداند (اصل Resume-by-default)
و نباید یک فایل JSON نیمه‌نوشته، آرتیفکت‌های قبلی را خراب کند (نوشتن اتمیک).
"""

from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path
from typing import Any, Dict, Optional

import torch


# ------------------------------------------------------------------------------
# نوشتن اتمیک
# ------------------------------------------------------------------------------
def atomic_write_json(data: Dict[str, Any], path: str) -> None:
    """
    نوشتن JSON با تضمین atomicity: ابتدا در فایل موقت نوشته، سپس rename
    می‌شود (rename در POSIX یک عملیات atomic است) تا در صورت قطع برق/کرش،
    فایل نهایی هرگز نیمه‌نوشته نباشد.
    """
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_path = tempfile.mkstemp(dir=str(p.parent), suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        os.replace(tmp_path, p)
    except Exception:
        if os.path.exists(tmp_path):
            os.remove(tmp_path)
        raise


def load_json(path: str) -> Optional[Dict[str, Any]]:
    p = Path(path)
    if not p.exists():
        return None
    with open(p, "r", encoding="utf-8") as f:
        return json.load(f)


# ------------------------------------------------------------------------------
# Checkpoint / Resume
# ------------------------------------------------------------------------------
def run_signature(variant: str, seed: int, config_hash: str) -> str:
    """شناسهٔ یکتای یک ران دقیق."""
    return f"{variant}__seed{seed}__{config_hash}"


def artifact_path(results_dir: str, variant: str, seed: int, config_hash: str) -> Path:
    sig = run_signature(variant, seed, config_hash)
    return Path(results_dir) / f"artifacts_{sig}.json"


def is_run_completed(results_dir: str, variant: str, seed: int, config_hash: str) -> bool:
    """
    بررسی وجود artifact کامل و معتبر برای این (variant, seed, hash).
    فقط وجود فایل کافی نیست؛ کلید 'completed': True هم باید باشد
    (جلوگیری از تلقی artifact نیمه‌نوشتهٔ کرش‌شده به‌عنوان کامل).
    """
    p = artifact_path(results_dir, variant, seed, config_hash)
    if not p.exists():
        return False
    data = load_json(str(p))
    return bool(data and data.get("completed") is True)


def save_checkpoint(state: Dict[str, Any], path: str) -> None:
    """
    ذخیرهٔ اتمیک checkpoint مدل/سرور (state_dict وزن‌ها + متادیتای راند).
    برای tensors از torch.save روی فایل موقت + os.replace استفاده می‌شود.
    """
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp_path = p.with_suffix(p.suffix + ".tmp")
    torch.save(state, tmp_path)
    os.replace(tmp_path, p)


def load_checkpoint(path: str, map_location: str = "cpu") -> Optional[Dict[str, Any]]:
    p = Path(path)
    if not p.exists():
        return None
    return torch.load(p, map_location=map_location)


def checkpoint_path(results_dir: str, variant: str, seed: int, config_hash: str) -> Path:
    sig = run_signature(variant, seed, config_hash)
    d = Path(results_dir) / "checkpoints"
    d.mkdir(parents=True, exist_ok=True)
    return d / f"ckpt_{sig}.pt"
