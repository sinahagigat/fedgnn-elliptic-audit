# -*- coding: utf-8 -*-
"""
losses.py — کتابخانهٔ مشترک توابع Loss پروژه (تک‌نقطهٔ حقیقت فرمول‌ها)
==============================================================================
اصل «تک‌نقطهٔ حقیقت»: هر فرمول Loss که در بیش از یک ماژول به کار می‌رود
(محاسبهٔ وزن کلاس مثبت، Loss تباینی prototype، Loss سازگاری گره مجازی)
اینجا به‌صورت canonical تعریف می‌شود. client.py از این توابع استفاده
می‌کند (متدهای داخلی آن Wrapperهای نازک روی همین توابع‌اند) تا هیچ فرمول
دوباره و به‌صورت ناهمگون در جای دیگری بازنویسی نشود.

محتوا:
  1) compute_pos_weight              — وزن کلاس مثبت برای CrossEntropy
  2) WeightedCrossEntropyLoss        — Wrapper استاندارد Loss طبقه‌بندی
  3) FocalLoss                        — جایگزین اختیاری برای دادهٔ به‌شدت نامتوازن
  4) PrototypeContrastiveLoss         — نسخهٔ Module نوآوری ۱
  5) virtual_node_consistency_loss    — Loss نوآوری ۲ (سازگاری گره مجازی)
"""

from __future__ import annotations

import logging
from typing import Dict, Optional

import torch
import torch.nn as nn
import torch.nn.functional as F

logger = logging.getLogger("fedgnn.losses")


# ==============================================================================
# ۱) محاسبهٔ وزن کلاس مثبت — منبع واحد (client.py._compute_pos_weight_tensor
#    باید منطقاً معادل همین باشد؛ اینجا نسخهٔ قابل‌استفادهٔ مجدد است)
# ==============================================================================
def compute_pos_weight(
    y: torch.Tensor,
    mask: torch.Tensor,
    max_pos_weight: float,
    device: Optional[str] = None,
) -> torch.Tensor:
    """
    وزن کلاس ۱ (تقلب) نسبت به کلاس ۰ برای مقابله با عدم توازن شدید Elliptic
    (نرخ مثبت ~9.76%). فرمول: min(n_neg / n_pos, max_pos_weight) — سقف
    max_pos_weight برای پیشگیری از انفجار Loss در کلاینت‌هایی که تعداد
    نمونهٔ مثبتشان بسیار کم است (مثلاً 1 یا 2 نمونه).
    """
    dev = device or y.device
    y_masked = y[mask]
    n_pos = int((y_masked == 1).sum().item())
    n_neg = int((y_masked == 0).sum().item())

    if n_pos == 0:
        pos_weight = 1.0  # هیچ نمونهٔ مثبتی نیست؛ وزن‌دهی بی‌معنی است
        logger.debug("⚠️ compute_pos_weight: هیچ نمونهٔ کلاس مثبت در mask نبود؛ وزن=1.0")
    else:
        pos_weight = min(n_neg / max(n_pos, 1), max_pos_weight)

    return torch.tensor([1.0, pos_weight], dtype=torch.float32, device=dev)


# ==============================================================================
# ۲) Wrapper استاندارد Weighted Cross-Entropy
# ==============================================================================
class WeightedCrossEntropyLoss(nn.Module):
    """
    Wrapper پایدار روی F.cross_entropy با وزن کلاس از پیش محاسبه‌شده.
    مقدار weight باید در سازنده یا از طریق update_weight تازه‌سازی شود
    (چون ترکیب کلاس‌ها بین کلاینت‌ها و راندها متفاوت است).
    """

    def __init__(self, class_weight: torch.Tensor):
        super().__init__()
        self.register_buffer("class_weight", class_weight)

    def update_weight(self, new_weight: torch.Tensor) -> None:
        self.class_weight = new_weight.to(self.class_weight.device)

    def forward(self, logits: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:
        return F.cross_entropy(logits, targets, weight=self.class_weight)


# ==============================================================================
# ۳) Focal Loss — جایگزین اختیاری (استفادهٔ احتمالی در تحلیل حساسیت)
# ==============================================================================
class FocalLoss(nn.Module):
    """
    Focal Loss (Lin et al., 2017) برای مواردی که Weighted-CE به‌تنهایی کافی
    نیست؛ گاما بالاتر → تمرکز بیشتر روی نمونه‌های سخت/کلاس اقلیت. این کلاس
    در واریانت‌های اصلی مقاله استفاده نمی‌شود (که همه از Weighted-CE
    استفاده می‌کنند) — صرفاً برای آزمایش حساسیت اختیاری (ablation) نگه
    داشته شده و صادقانه به همین صورت در مقاله ذکر خواهد شد.
    """

    def __init__(self, gamma: float = 2.0, class_weight: Optional[torch.Tensor] = None):
        super().__init__()
        self.gamma = gamma
        self.register_buffer("class_weight", class_weight if class_weight is not None else torch.tensor([1.0, 1.0]))

    def forward(self, logits: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:
        ce = F.cross_entropy(logits, targets, weight=self.class_weight, reduction="none")
        pt = torch.exp(-ce)
        focal = ((1 - pt) ** self.gamma) * ce
        return focal.mean()


# ==============================================================================
# ۴) Prototype Contrastive Loss — نسخهٔ Module نوآوری ۱
# ==============================================================================
class PrototypeContrastiveLoss(nn.Module):
    """
    نسخهٔ Module-ای همان فرمول contrastive بین امبدینگ گره و prototype
    سراسری کلاسش (پیاده‌سازی متد client.FederatedClient._prototype_loss
    منطقاً باید معادل همین forward باشد). فرمول:

        L_proto = CrossEntropy( sim(emb, prototypes) / T , label_idx )

    که sim شباهت کسینوسی نرمال‌شده و T دمای prototype (fed_cfg.prototype_temperature)
    است. دمای پایین‌تر → توزیع sim تیزتر → جریمهٔ سخت‌گیرانه‌تر برای دوری از
    prototype کلاس درست.
    """

    def __init__(self, temperature: float):
        super().__init__()
        assert temperature > 0, "❌ دمای prototype باید مثبت باشد."
        self.temperature = temperature

    def forward(
        self,
        node_emb: torch.Tensor,
        labels: torch.Tensor,
        global_prototypes: Dict[int, torch.Tensor],
    ) -> torch.Tensor:
        if not global_prototypes or node_emb.shape[0] == 0:
            return torch.tensor(0.0, device=node_emb.device)

        class_ids = sorted(global_prototypes.keys())
        if len(class_ids) < 2:
            return torch.tensor(0.0, device=node_emb.device)

        proto_matrix = torch.stack([global_prototypes[c] for c in class_ids]).to(node_emb.device)

        valid_mask = torch.tensor(
            [int(l.item()) in class_ids for l in labels], device=node_emb.device
        )
        if valid_mask.sum() == 0:
            return torch.tensor(0.0, device=node_emb.device)

        emb_valid = node_emb[valid_mask]
        labels_valid = labels[valid_mask]
        label_idx = torch.tensor(
            [class_ids.index(int(l.item())) for l in labels_valid], device=node_emb.device
        )

        emb_norm = F.normalize(emb_valid, dim=-1)
        proto_norm = F.normalize(proto_matrix, dim=-1)
        sims = (emb_norm @ proto_norm.t()) / self.temperature

        return F.cross_entropy(sims, label_idx)


# ==============================================================================
# ۵) Virtual Node Consistency Loss — نسخهٔ عمومی نوآوری ۲
# ==============================================================================
def virtual_node_consistency_loss(
    local_virtual_emb: torch.Tensor,
    global_virtual_ref: Optional[torch.Tensor],
) -> torch.Tensor:
    """
    جریمهٔ MSE بین بردار گره‌های مجازی محاسبه‌شده توسط کلاینت جاری و مرجع
    سراسری (میانگین‌وزنی همهٔ کلاینت‌ها از راند قبل) — با کمینه‌کردن این
    Loss، هر کلاینت گره‌های مجازی خود را با فضای مشترک بین کلاینتی
    هم‌راستا می‌کند بدون افشای ویژگی خام گره‌های مرزی خودش.

    اگر مرجع سراسری هنوز موجود نباشد (راند اول)، Loss صفر برمی‌گردد —
    این حالت طبیعی است، نه خطا.
    """
    if global_virtual_ref is None:
        return torch.tensor(0.0, device=local_virtual_emb.device)

    ref = global_virtual_ref.to(local_virtual_emb.device)
    # اگر ابعاد گره‌های مجازی محلی با مرجع سراسری مطابقت نداشت، fail-fast
    assert local_virtual_emb.shape[-1] == ref.shape[-1], (
        f"❌ عدم تطابق ابعاد گره مجازی: محلی={local_virtual_emb.shape[-1]}, "
        f"مرجع سراسری={ref.shape[-1]}"
    )
    return F.mse_loss(local_virtual_emb.mean(dim=0), ref)
