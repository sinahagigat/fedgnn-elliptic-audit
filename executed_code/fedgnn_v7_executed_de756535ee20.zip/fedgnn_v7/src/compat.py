# -*- coding: utf-8 -*-
"""
compat.py — پل سازگاری نام‌های صفت میان کدِ مصرف‌کننده و فیلدهای واقعی کانفیگ.
==============================================================================
مسئله: ماژول‌هایی مثل virtual_nodes.py و privacy.py صفت‌ها را با پیشوند بخش
صدا می‌زنند (cfg.virtual_momentum) در حالی که کلاس کانفیگ آن را بدون پیشوند
تعریف کرده است (momentum). این فایل یک __getattr__ پشتیبان روی کلاس‌های کانفیگ
نصب می‌کند که نام درخواستی را به فیلد واقعی نگاشت می‌کند.

⚠️ این یک پل موقت است، نه راه‌حل نهایی. هر نگاشت با هشدار WARNING لاگ می‌شود؛
پیش از تحویل نهایی باید همان نگاشت‌ها را به‌صورت rename دائمی در کد اعمال کرد
تا اصل «تک نقطهٔ حقیقت» نقض‌شده باقی نماند. تابع compat_report() فهرست کامل
نگاشت‌های استفاده‌شده را برای همین کار چاپ می‌کند.
"""

from __future__ import annotations

import dataclasses
import difflib
import inspect
import logging
from typing import Any, Dict, List, Optional, Set

logger = logging.getLogger("fedgnn.compat")

# ثبت هر نگاشتِ انجام‌شده برای گزارش نهایی: "ClassName.requested" -> "actual"
_RESOLVED: Dict[str, str] = {}
_ANNOUNCED: Set[str] = set()

# واژه‌هایی که به‌عنوان پیشوند/پسوندِ نامِ بخش تکرار می‌شوند و قابل حذف‌اند
_SECTION_WORDS = {
    "virtual", "vn", "privacy", "dp", "model", "fed", "data", "partition",
    "selection", "sel", "agg", "aggregation", "blockchain", "chain", "rust",
    "experiment", "exp", "proto", "prototype", "cfg", "config",
}

# پیشوندهای بولی/شمارشی که ممکن است در یک طرف باشند و در طرف دیگر نه
_AFFIXES = ("num_", "n_", "use_", "enable_", "is_", "do_", "with_")

# نگاشت‌های صریح برای مواردی که حدس ساختاری کافی نیست.
# ترتیب مهم است: اولین نامی که در کلاس وجود داشته باشد انتخاب می‌شود.
_EXPLICIT: Dict[str, List[str]] = {
    # --- VirtualNodeConfig ---
    "num_virtual_nodes":      ["num_nodes", "n_nodes", "num_virtual", "n_virtual", "count"],
    "virtual_momentum":       ["momentum", "ema_momentum", "update_momentum"],
    "virtual_residual_weight":["residual_weight", "alpha", "mix_weight", "beta"],
    "virtual_loss_weight":    ["loss_weight", "lambda_virtual", "weight"],
    "virtual_temperature":    ["temperature", "tau"],
    # --- PrivacyConfig ---
    "enabled":                ["enable", "enable_dp", "use_dp", "dp_enabled", "active"],
    "clip_norm":              ["dp_clip_norm", "max_grad_norm", "grad_clip_norm",
                               "l2_clip", "clipping_norm"],
    "noise_multiplier":       ["dp_noise_multiplier", "sigma", "noise_std", "noise_sigma"],
    "delta":                  ["dp_delta", "target_delta"],
    "epsilon":                ["dp_epsilon", "target_epsilon"],
    # --- ModelConfig ---
    "use_residual":           ["residual"],
    "residual":               ["use_residual"],
    "hidden":                 ["hidden_dim"],
    "heads":                  ["gat_heads", "num_heads"],
}


# ==============================================================================
# استخراج فیلدهای واقعی یک شیء کانفیگ (pydantic v2 / dataclass / ساده)
# ==============================================================================
def _field_names(obj: Any) -> List[str]:
    cls = type(obj)
    names: Set[str] = set()

    mf = getattr(cls, "model_fields", None)          # pydantic v2
    if isinstance(mf, dict):
        names |= set(mf.keys())

    if dataclasses.is_dataclass(cls):
        names |= {f.name for f in dataclasses.fields(cls)}

    if not names:                                     # کلاس ساده
        try:
            names |= {k for k in vars(obj) if not k.startswith("_")}
        except TypeError:
            pass
    return sorted(names)


# ==============================================================================
# تولید نامزدهای نگاشت — قطعی و قابل‌بازرسی
# ==============================================================================
def _candidates(name: str) -> List[str]:
    out: List[str] = []

    def add(s: str) -> None:
        if s and s != name and s not in out:
            out.append(s)

    # ۱) نگاشت صریح
    for c in _EXPLICIT.get(name, []):
        add(c)

    toks = name.split("_")

    # ۲) حذف واژه‌های نامِ بخش از هر جای نام
    kept = [t for t in toks if t not in _SECTION_WORDS]
    if kept and kept != toks:
        add("_".join(kept))

    # ۳) حذف پیشوندهای بولی/شمارشی
    for p in _AFFIXES:
        if name.startswith(p):
            add(name[len(p):])
            rest = [t for t in name[len(p):].split("_") if t not in _SECTION_WORDS]
            if rest:
                add("_".join(rest))
                add(p + "_".join(rest))

    # ۴) افزودن پیشوندها
    for p in _AFFIXES:
        add(p + name)

    # ۵) مفرد/جمع
    if name.endswith("s"):
        add(name[:-1])
    else:
        add(name + "s")

    return out


def _resolve(obj: Any, requested: str) -> Optional[str]:
    """نامِ فیلد واقعی متناظر با requested، یا None."""
    fields = _field_names(obj)
    if not fields:
        return None
    fset = set(fields)

    for cand in _candidates(requested):
        if cand in fset:
            return cand

    # آخرین تلاش: تطبیق فازی سخت‌گیرانه (فقط برای نام‌های ≥۶ حرف)
    if len(requested) >= 6:
        near = difflib.get_close_matches(requested, fields, n=1, cutoff=0.78)
        if near:
            return near[0]
        stripped = "_".join(t for t in requested.split("_") if t not in _SECTION_WORDS)
        if stripped and len(stripped) >= 5:
            near = difflib.get_close_matches(stripped, fields, n=1, cutoff=0.78)
            if near:
                return near[0]
    return None


# ==============================================================================
# نصب __getattr__ پشتیبان
# ==============================================================================
def _make_fallback(cls_name: str, original):
    def __getattr__(self, item):                      # فقط وقتی lookup عادی شکست بخورد
        if item.startswith("_") or item in ("model_fields", "model_config",
                                            "model_computed_fields"):
            if original is not None:
                return original(self, item)
            raise AttributeError(item)

        target = _resolve(self, item)
        if target is not None:
            key = f"{cls_name}.{item}"
            _RESOLVED[key] = target
            if key not in _ANNOUNCED:
                _ANNOUNCED.add(key)
                logger.warning(
                    f"🔗 نگاشت سازگاری: {cls_name}.{item} → {cls_name}.{target} "
                    f"(پیش از تحویل نهایی، نام را در کد اصلاح کنید)"
                )
            return object.__getattribute__(self, target)

        if original is not None:
            try:
                return original(self, item)
            except AttributeError:
                pass

        raise AttributeError(
            f"'{cls_name}' فیلدی به نام '{item}' ندارد و هیچ نگاشت سازگاری "
            f"یافت نشد. فیلدهای موجود: {_field_names(self)}"
        )

    return __getattr__


def install_config_compat(config_module) -> int:
    """روی همهٔ کلاس‌های کانفیگِ ماژول داده‌شده، پشتیبانِ نام نصب می‌کند."""
    n = 0
    for name, obj in vars(config_module).items():
        if not inspect.isclass(obj) or name.startswith("_"):
            continue
        is_cfg = (isinstance(getattr(obj, "model_fields", None), dict)
                  or dataclasses.is_dataclass(obj))
        if not is_cfg:
            continue
        if getattr(obj, "_fedgnn_compat_installed", False):
            continue
        original = obj.__dict__.get("__getattr__", None)
        obj.__getattr__ = _make_fallback(name, original)
        obj._fedgnn_compat_installed = True
        n += 1
    logger.info(f"🧩 لایهٔ سازگاری کانفیگ روی {n} کلاس نصب شد.")
    return n


def compat_report() -> Dict[str, str]:
    """فهرست نگاشت‌های واقعاً استفاده‌شده — همین‌ها را باید دائمی کرد."""
    if _RESOLVED:
        logger.info("=" * 70)
        logger.info(f"🧩 {len(_RESOLVED)} نگاشت سازگاری در این اجرا استفاده شد:")
        for k, v in sorted(_RESOLVED.items()):
            cls = k.split(".")[0]
            logger.info(f"   • {k}  →  {cls}.{v}")
        logger.info("=" * 70)
    else:
        logger.info("✅ هیچ نگاشت سازگاری لازم نشد — نام‌ها هم‌راستا هستند.")
    return dict(_RESOLVED)


# ==============================================================================
# فراخوانی مقاوم مدل — نامِ پارامتر سومِ forward را از امضا می‌خواند
# ==============================================================================
_FWD_CACHE: Dict[type, Optional[str]] = {}


def _boundary_param(model) -> Optional[str]:
    cls = type(model)
    if cls in _FWD_CACHE:
        return _FWD_CACHE[cls]
    kw: Optional[str] = None
    try:
        params = list(inspect.signature(cls.forward).parameters.values())
        for p in params[3:]:                          # پس از self, x, edge_index
            if p.kind in (p.POSITIONAL_OR_KEYWORD, p.KEYWORD_ONLY):
                kw = p.name
                break
        if kw is None and any(p.kind == p.VAR_KEYWORD for p in params):
            kw = "boundary_idx"
    except (TypeError, ValueError):
        kw = None
    _FWD_CACHE[cls] = kw
    return kw


def safe_forward(model, x, edge_index, boundary=None):
    """
    model(x, edge_index, <boundary>) را با نام صحیح آرگومان صدا می‌زند.
    خروجی همیشه به‌صورت (node_emb یا None, logits) نرمال می‌شود.
    """
    kw = _boundary_param(model)
    if boundary is not None and kw is not None:
        out = model(x, edge_index, **{kw: boundary})
    elif kw is not None:
        out = model(x, edge_index, **{kw: None})
    else:
        out = model(x, edge_index)

    if isinstance(out, (tuple, list)):
        return (out[0] if len(out) > 1 else None), out[-1]
    return None, out
