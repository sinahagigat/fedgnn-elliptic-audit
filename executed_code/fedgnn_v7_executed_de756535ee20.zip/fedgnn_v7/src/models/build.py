# -*- coding: utf-8 -*-
"""
build.py — کارخانهٔ ساخت مدل کامل هر واریانت
==============================================================================
هر واریانت (Centralized_GCN, FedAvg_GCN, FedProto_GCN, FedGNN_Hard_GCN,
FedGNN_SoftSelective_GCN, FedGNN_SoftSelective_Virtual_GCN,
FedGNN_SoftSelective_Virtual_GAT, ...) در نهایت از همین FedGNNModel
ساخته می‌شود؛ تفاوت واریانت‌ها در سطح آموزش/تجمیع (بلوک ۴ و ۵) است، نه
در معماری شبکه — این طراحی باعث می‌شود مقایسه‌ها «تمیز» (apples-to-apples)
باشند و تفاوت عملکرد صرفاً به الگوریتم فدرال نسبت داده شود، نه به معماری.
"""

from __future__ import annotations

import logging
from typing import Optional

import torch
import torch.nn as nn

from src.config import ModelConfig, VirtualNodeConfig
from src.models.encoders import build_encoder
from src.models.virtual_nodes import VirtualNodeModule

logger = logging.getLogger("fedgnn.models.build")


class FedGNNModel(nn.Module):
    """
    بستهٔ کامل مدل یک کلاینت (یا نسخهٔ متمرکز): رمزگذار GCN/GAT +
    به‌صورت اختیاری لایهٔ گره مجازی.

    نکتهٔ طراحی مهم: خروجی logits نهایی از روی node_emb *پس از* اعمال
    گره مجازی محاسبه می‌شود (اگر فعال باشد) — یعنی گره مجازی واقعاً روی
    تصمیم طبقه‌بندی گره‌های مرزی اثر می‌گذارد، نه صرفاً یک بار جانبی.
    """

    def __init__(
        self,
        in_dim: int,
        model_cfg: ModelConfig,
        virtual_cfg: Optional[VirtualNodeConfig] = None,
        use_virtual_nodes: bool = False,
        num_classes: int = 2,
    ):
        super().__init__()
        self.model_cfg = model_cfg
        self.use_virtual_nodes = use_virtual_nodes and virtual_cfg is not None

        self.encoder = build_encoder(in_dim, model_cfg, num_classes=num_classes)

        # سر طبقه‌بند مجزا (بعد از احتمالاً گره مجازی) — encoder.classifier
        # صرفاً برای حالت بدون گره مجازی استفاده می‌شود؛ در حالت فعال، از
        # این طبقه‌بند دوم استفاده می‌کنیم تا وزن‌ها مستقل نگه داشته شوند.
        self.final_classifier = nn.Linear(model_cfg.hidden_dim, num_classes)

        if self.use_virtual_nodes:
            self.virtual_module = VirtualNodeModule(model_cfg.hidden_dim, virtual_cfg)
            # پروجکشن payload خام ویژگی → فضای پنهان (چون payload از فضای
            # ویژگی خام F می‌آید، نه از فضای hidden)
            self.payload_proj = nn.Linear(in_dim, model_cfg.hidden_dim)
            # HONESTY-FIX: خروجی این لایه فقط به .data و لنگر detach‌شده می‌رود ⇒
            # هرگز گرادیان نمی‌گیرد. صریحاً فریز می‌شود تا در n_params آموزش‌پذیر
            # شمرده نشود و در مقاله به‌عنوان «تصویرسازی تصادفی ثابت» گزارش گردد.
            for _p in self.payload_proj.parameters():
                _p.requires_grad_(False)
        else:
            self.virtual_module = None
            self.payload_proj = None

    def forward(
        self,
        x: torch.Tensor,
        edge_index: torch.Tensor,
        boundary_local_idx: Optional[torch.Tensor] = None,
    ):
        node_emb, _ = self.encoder(x, edge_index)

        if self.use_virtual_nodes and boundary_local_idx is not None:
            node_emb = self.virtual_module(node_emb, boundary_local_idx)

        logits = self.final_classifier(node_emb)
        return node_emb, logits

    def set_virtual_reference(self, raw_payload: torch.Tensor):
        """پروجکت‌کردن payload خام مرزی (از federated_dataset.py) به فضای
        hidden و تزریق آن به VirtualNodeModule به‌عنوان مرجع راند جاری."""
        if not self.use_virtual_nodes:
            return
        projected = self.payload_proj(raw_payload.unsqueeze(0))  # [1, H]
        self.virtual_module.set_external_reference(projected)

    def get_virtual_node_loss(self) -> torch.Tensor:
        if not self.use_virtual_nodes:
            return torch.tensor(0.0, device=next(self.parameters()).device)
        return self.virtual_module.compute_virtual_node_loss()


def build_model(
    in_dim: int,
    model_cfg: ModelConfig,
    virtual_cfg: Optional[VirtualNodeConfig] = None,
    use_virtual_nodes: bool = False,
    num_classes: int = 2,
    device: str = "cuda",
) -> FedGNNModel:
    """نقطهٔ ورود واحد برای ساخت مدل — همهٔ واریانت‌ها از اینجا عبور می‌کنند."""
    model = FedGNNModel(
        in_dim=in_dim,
        model_cfg=model_cfg,
        virtual_cfg=virtual_cfg,
        use_virtual_nodes=use_virtual_nodes,
        num_classes=num_classes,
    ).to(device)

    n_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    logger.info(
        f"🧠 مدل ساخته شد | arch={model_cfg.arch} | virtual_nodes={use_virtual_nodes} | "
        f"پارامترها={n_params:,} | device={device}"
    )
    return model
