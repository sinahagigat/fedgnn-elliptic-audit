# -*- coding: utf-8 -*-
"""
virtual_nodes.py — لایهٔ گره مجازی (نوآوری ۲: Virtual-Node Alignment)
==============================================================================
هدف: جبران قطع‌شدن یال‌های مرزی هنگام پارتیشن‌بندی، بدون افشای دادهٔ خام
گره‌های همسایهٔ خارج از کلاینت.

مکانیزم:
  1) هر کلاینت K گرهٔ مجازی یادگیرنده دارد (num_virtual_nodes، پیش‌فرض ۸).
  2) بردار هر گرهٔ مجازی، میانگین وزن‌دارِ payload تجمیعی (mean/var) دریافتی
     از سایر کلاینت‌ها (محاسبه‌شده در federated_dataset.compute_boundary_
     exchange_payload) است؛ یعنی یک «نمایندهٔ ناشناس» از همسایگی بیرونی.
  3) هر گرهٔ مرزی واقعی (local_boundary_idx) در پیام‌رسانی گرافی، علاوه بر
     همسایه‌های واقعی داخل کلاینت، به نزدیک‌ترین گرهٔ مجازی هم متصل می‌شود
     (اتصال دوطرفه، شبیه‌سازی‌شده با یک لایهٔ attention سبک به‌جای اضافه
     کردن یال واقعی به edge_index — برای سادگی و پایداری آموزش).
  4) virtual_node_loss یک جریمهٔ MSE بین بردار نهایی گره مجازی (پس از
     به‌روزرسانی محلی) و payload دریافتی «مرجع» است — تا گره مجازی از
     نمایندگی خود منحرف نشود (لنگر حریم‌خصوصی‌محور).
"""

from __future__ import annotations

from typing import Dict, Optional

import torch
import torch.nn as nn
import torch.nn.functional as F

from src.config import VirtualNodeConfig


class VirtualNodeModule(nn.Module):
    """
    ماژول گره‌های مجازی؛ به‌صورت یک لایهٔ جداگانه بعد از رمزگذار اصلی
    (GCN/GAT) روی بردارهای پنهان گره‌های مرزی اعمال می‌شود.
    """

    # P0-8-fix: پیش‌فرض کلاسی لنگر مرجع (پیش از نخستین اجماع سرور)
    _last_reference_payload = None

    def __init__(self, hidden_dim: int, cfg: VirtualNodeConfig):
        super().__init__()
        self.cfg = cfg
        self.hidden_dim = hidden_dim
        self.num_virtual = cfg.num_virtual

        # امبدینگ پایه گره‌های مجازی — با payload خارجی هر راند بازنشانی/آپدیت می‌شود
        self.virtual_embed = nn.Parameter(torch.zeros(self.num_virtual, hidden_dim))
        nn.init.xavier_uniform_(self.virtual_embed)

        # لایهٔ Attention سبک برای اتصال گره مرزی ↔ گره مجازی
        self.query_proj = nn.Linear(hidden_dim, hidden_dim, bias=False)
        self.key_proj = nn.Linear(hidden_dim, hidden_dim, bias=False)
        self.value_proj = nn.Linear(hidden_dim, hidden_dim, bias=False)
        self.out_proj = nn.Linear(hidden_dim, hidden_dim)
        self.scale = hidden_dim ** 0.5

        self._last_reference_payload: Optional[torch.Tensor] = None  # برای virtual_node_loss

    def set_external_reference(self, incoming_payload_matrix):
        """
        دریافت payload اجماعی سرور و ذخیرهٔ آن به‌عنوان «لنگر» مرجع راند.

        P0-8-fix — سه ایراد نسخهٔ قبل رفع شد:
          (۱) متغیر consensus در «هر دو» شاخه تعریف می‌شود (رفع NameError).
          (۲) لنگر = اجماع خالص سرور، پیش از آمیختن مومنتومی با مقدار محلی.
          (۳) شکل/دستگاه/نوع ورودی نرمال و صریحاً بررسی می‌شود (fail-fast).
        """
        if incoming_payload_matrix is None:
            self._last_reference_payload = None
            return

        with torch.no_grad():
            payload = incoming_payload_matrix
            if not torch.is_tensor(payload):
                payload = torch.as_tensor(payload)
            payload = payload.to(device=self.virtual_embed.device,
                                 dtype=self.virtual_embed.dtype)
            if payload.dim() == 1:
                payload = payload.unsqueeze(0)

            H = self.virtual_embed.shape[-1]
            assert payload.shape[-1] == H, (
                f"[virtual_nodes] بُعد payload ({payload.shape[-1]}) با فضای "
                f"پنهان گره مجازی ({H}) هم‌خوان نیست — پروجکشن در client.py لازم است."
            )

            if payload.shape[0] == self.num_virtual:
                consensus = payload
            else:
                consensus = payload.mean(dim=0, keepdim=True) \
                                   .expand(self.num_virtual, -1)
            consensus = consensus.contiguous().clone()

            m = float(self.cfg.momentum)
            self.virtual_embed.data = (
                m * self.virtual_embed.data + (1.0 - m) * consensus
            )
            self._last_reference_payload = consensus.detach().clone()

    def forward(
        self,
        node_emb: torch.Tensor,
        boundary_local_idx: torch.Tensor,
    ) -> torch.Tensor:
        """
        به‌روزرسانی بردار گره‌های مرزی با اطلاعات گره‌های مجازی از طریق
        یک بلوک attention تک‌سر (scaled dot-product)، سپس بازگرداندن
        node_emb به‌روزشدهٔ کامل (بقیهٔ گره‌ها دست‌نخورده باقی می‌مانند).

        Args:
            node_emb: [N_local, H] بردار پنهان تمام گره‌های کلاینت
            boundary_local_idx: [n_boundary] اندیس محلی گره‌های مرزی

        Returns:
            node_emb_updated: [N_local, H]
        """
        if boundary_local_idx.numel() == 0:
            return node_emb  # کلاینتی بدون گرهٔ مرزی — بدون تغییر

        h_boundary = node_emb[boundary_local_idx]              # [B, H]
        q = self.query_proj(h_boundary)                        # [B, H]
        k = self.key_proj(self.virtual_embed)                  # [V, H]
        v = self.value_proj(self.virtual_embed)                # [V, H]

        attn_scores = (q @ k.t()) / self.scale                 # [B, V]
        attn_weights = F.softmax(attn_scores, dim=-1)
        context = attn_weights @ v                              # [B, H]
        context = self.out_proj(context)

        h_boundary_updated = h_boundary + self.cfg.residual_weight * context

        node_emb_updated = node_emb.clone()
        node_emb_updated[boundary_local_idx] = h_boundary_updated
        return node_emb_updated

    def compute_virtual_node_loss(self) -> torch.Tensor:
        """
        جریمهٔ MSE بین گره‌های مجازی جاری و آخرین مرجع دریافتی از سرور —
        لنگر می‌زند تا گره‌های مجازی در طول local_epochs از نمایندگی
        تجمیعی خود منحرف نشوند (خصوصاً وقتی local_epochs>۱ در آینده تغییر کند).
        """
        if self._last_reference_payload is None:
            return torch.tensor(0.0, device=self.virtual_embed.device)
        return F.mse_loss(self.virtual_embed, self._last_reference_payload)

    def get_outgoing_payload(self) -> torch.Tensor:
        """بردار خلاصهٔ گره‌های مجازی برای ارسال به سرور/سایر کلاینت‌ها در راند بعد."""
        return self.virtual_embed.detach().clone()
