# -*- coding: utf-8 -*-
"""
encoders.py — رمزگذارهای گرافی GCN و GAT
==============================================================================
هر دو رمزگذار یک رابط یکسان دارند: forward(x, edge_index) -> (node_emb, logits)
تا build.py بتواند بدون شرط‌گذاری زیاد، آن‌ها را به لایهٔ گره مجازی و سر
طبقه‌بند وصل کند. node_emb همان بردار پنهان لایهٔ آخر (پیش از طبقه‌بندی) است
که هم برای محاسبهٔ Prototype (نوآوری ۱) و هم برای اتصال گره‌های مجازی
(نوآوری ۲) استفاده می‌شود.
"""

from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import GCNConv, GATConv

from src.config import ModelConfig


class GCNEncoder(nn.Module):
    """
    رمزگذار GCN چندلایه با dropout، batch-norm سبک (اختیاری) و اتصال
    باقیمانده (residual) بین لایه‌ها برای جلوگیری از over-smoothing —
    که در گراف‌های کم‌یال (مثل پارتیشن‌های ما با edge_retention≈۱۵-۳۰٪)
    اهمیت بیشتری هم دارد.
    """

    def __init__(self, in_dim: int, cfg: ModelConfig, num_classes: int = 2):
        super().__init__()
        self.cfg = cfg
        hidden = cfg.hidden_dim
        self.convs = nn.ModuleList()
        self.norms = nn.ModuleList()

        dims = [in_dim] + [hidden] * cfg.num_layers
        for i in range(cfg.num_layers):
            self.convs.append(GCNConv(dims[i], dims[i + 1], add_self_loops=True))
            self.norms.append(nn.LayerNorm(dims[i + 1]))

        self.dropout = nn.Dropout(cfg.dropout)
        self.use_residual = getattr(cfg, "residual", False) and in_dim == hidden
        self.classifier = nn.Linear(hidden, num_classes)

    def forward(self, x: torch.Tensor, edge_index: torch.Tensor):
        h = x
        for i, (conv, norm) in enumerate(zip(self.convs, self.norms)):
            h_new = conv(h, edge_index)
            h_new = norm(h_new)
            h_new = F.relu(h_new)
            h_new = self.dropout(h_new)
            if self.use_residual and i > 0 and h_new.shape == h.shape:
                h_new = h_new + h
            h = h_new

        logits = self.classifier(h)
        return h, logits


class GATEncoder(nn.Module):
    """
    رمزگذار GAT چندلایه با concat=True در لایه‌های میانی (برای حفظ
    ظرفیت بیانی چندسر) و concat=False (میانگین‌گیری سرها) در لایهٔ آخر
    تا ابعاد خروجی دقیقاً برابر hidden_dim بماند — سازگار با build.py
    و لایهٔ گره مجازی که ابعاد ثابت انتظار دارند.
    """

    def __init__(self, in_dim: int, cfg: ModelConfig, num_classes: int = 2):
        super().__init__()
        self.cfg = cfg
        hidden = cfg.hidden_dim
        heads = cfg.gat_heads
        self.convs = nn.ModuleList()
        self.norms = nn.ModuleList()

        in_dims = [in_dim] + [hidden] * (cfg.num_layers - 1)
        for i in range(cfg.num_layers):
            is_last = i == cfg.num_layers - 1
            out_per_head = hidden if is_last else hidden // heads
            concat = not is_last
            self.convs.append(
                GATConv(
                    in_dims[i],
                    out_per_head,
                    heads=heads,
                    concat=concat,
                    dropout=cfg.dropout,
                    add_self_loops=True,
                )
            )
            out_dim = out_per_head * heads if concat else out_per_head
            self.norms.append(nn.LayerNorm(out_dim))

        self.dropout = nn.Dropout(cfg.dropout)
        self.use_residual = getattr(cfg, "residual", False) and in_dim == hidden
        self.classifier = nn.Linear(hidden, num_classes)

    def forward(self, x: torch.Tensor, edge_index: torch.Tensor):
        h = x
        for i, (conv, norm) in enumerate(zip(self.convs, self.norms)):
            h_new = conv(h, edge_index)
            h_new = norm(h_new)
            h_new = F.elu(h_new)
            h_new = self.dropout(h_new)
            if self.use_residual and i > 0 and h_new.shape == h.shape:
                h_new = h_new + h
            h = h_new

        logits = self.classifier(h)
        return h, logits


class MLPEncoder(nn.Module):
    """
    v7: graph-free control. Same depth, width, LayerNorm, ReLU and dropout as
    GCNEncoder, but each layer is a Linear map, so edge_index is ignored.
    A GCN that does not beat this encoder is not using the graph.
    """

    def __init__(self, in_dim: int, cfg: ModelConfig, num_classes: int = 2):
        super().__init__()
        self.cfg = cfg
        hidden = cfg.hidden_dim
        dims = [in_dim] + [hidden] * cfg.num_layers
        self.lins = nn.ModuleList(nn.Linear(dims[i], dims[i + 1]) for i in range(cfg.num_layers))
        self.norms = nn.ModuleList(nn.LayerNorm(dims[i + 1]) for i in range(cfg.num_layers))
        self.dropout = nn.Dropout(cfg.dropout)
        self.classifier = nn.Linear(hidden, num_classes)

    def forward(self, x: torch.Tensor, edge_index: torch.Tensor):
        h = x
        for lin, norm in zip(self.lins, self.norms):
            h = self.dropout(F.relu(norm(lin(h))))
        return h, self.classifier(h)


_ENCODER_REGISTRY = {"gcn": GCNEncoder, "gat": GATEncoder, "mlp": MLPEncoder}


def build_encoder(in_dim: int, cfg: ModelConfig, num_classes: int = 2) -> nn.Module:
    """کارخانهٔ ساخت رمزگذار بر اساس cfg.arch (\"gcn\" یا \"gat\")."""
    arch = cfg.arch.lower()
    if arch not in _ENCODER_REGISTRY:
        raise ValueError(f"❌ معماری ناشناخته: {arch}. گزینه‌های معتبر: {list(_ENCODER_REGISTRY)}")
    return _ENCODER_REGISTRY[arch](in_dim, cfg, num_classes)
