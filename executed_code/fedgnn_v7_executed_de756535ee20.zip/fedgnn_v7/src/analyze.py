# -*- coding: utf-8 -*-
"""
analyze.py — تولید جدول‌ها و گزارش نهایی از artifacts.json برای مقاله
==============================================================================
مسئولیت‌ها:
  1) بارگذاری artifacts.json و فیلتر کردن فقط رانهای status="completed"
  2) ساخت جدول خلاصه (mean ± std روی seedها) برای هر واریانت × هر متریک
  3) گزارش وضعیت converged (چند از N ران به همگرایی رسیده‌اند)
  4) مقایسهٔ آماری همهٔ واریانت‌ها در برابر baseline (با stats.py)
  5) خروجی هم به CSV/JSON (برای بررسی دستی) و هم متن جدول LaTeX (برای
     چسباندن مستقیم در مقاله)
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Dict, List, Optional

import numpy as np
import pandas as pd

from src.stats import compare_all_variants_vs_baseline, tost_equivalence_test

logger = logging.getLogger("fedgnn.analyze")

METRICS_OF_INTEREST = ["ap", "auc", "f1", "precision", "recall"]


# ==============================================================================
# بارگذاری و فیلتر artifacts
# ==============================================================================
def load_completed_runs(artifacts_path: Path) -> Dict[str, dict]:
    assert artifacts_path.exists(), f"❌ فایل artifacts پیدا نشد: {artifacts_path}"
    with open(artifacts_path, "r", encoding="utf-8") as f:
        artifacts = json.load(f)
    runs = artifacts.get("runs", {})
    completed = {k: v for k, v in runs.items() if v.get("status") == "completed"}
    failed = {k: v for k, v in runs.items() if v.get("status") == "failed"}
    if failed:
        logger.warning(f"⚠️ {len(failed)} ران با status='failed' از تحلیل کنار گذاشته شدند: {list(failed.keys())}")
    logger.info(f"📊 {len(completed)} ران کامل برای تحلیل بارگذاری شد.")
    return completed


def group_runs_by_variant(completed_runs: Dict[str, dict]) -> Dict[str, List[dict]]:
    grouped: Dict[str, List[dict]] = {}
    for run in completed_runs.values():
        grouped.setdefault(run["variant_name"], []).append(run)
    return grouped


# ==============================================================================
# جدول خلاصه — mean ± std روی seedها برای هر متریک
# ==============================================================================
def build_summary_table(grouped_runs: Dict[str, List[dict]]) -> pd.DataFrame:
    """
    ساخت DataFrame با یک ردیف به ازای هر واریانت، شامل mean/std هر متریک
    روی همهٔ seedهایی که برای آن واریانت کامل شده‌اند + تعداد seed واقعی
    (برای اینکه اگر یک واریانت کمتر از N seed کامل شده، در جدول شفاف باشد
    و به‌اشتباه به‌عنوان نتیجهٔ کامل ارائه نشود).
    """
    rows = []
    for variant_name, runs in grouped_runs.items():
        row: Dict[str, object] = {"variant": variant_name, "n_seeds": len(runs)}
        row["n_converged"] = sum(1 for r in runs if r.get("converged", False))

        for metric in METRICS_OF_INTEREST:
            values = [r["test_metrics"][metric] for r in runs if not np.isnan(r["test_metrics"][metric])]
            if values:
                row[f"{metric}_mean"] = round(float(np.mean(values)), 4)
                row[f"{metric}_std"] = round(float(np.std(values, ddof=1)) if len(values) > 1 else 0.0, 4)
            else:
                row[f"{metric}_mean"], row[f"{metric}_std"] = float("nan"), float("nan")

        row["avg_runtime_sec"] = round(float(np.mean([r["runtime_sec"] for r in runs])), 2)
        rows.append(row)

    df = pd.DataFrame(rows).sort_values("ap_mean", ascending=False).reset_index(drop=True)
    return df


# ==============================================================================
# گزارش همگرایی — شفافیت کامل روی رانهایی که به converged=True نرسیدند
# ==============================================================================
def convergence_report(grouped_runs: Dict[str, List[dict]]) -> pd.DataFrame:
    rows = []
    for variant_name, runs in grouped_runs.items():
        for r in runs:
            rows.append({
                "variant": variant_name,
                "seed": r["seed"],
                "converged": r.get("converged", False),
                "best_round_idx": r.get("best_round_idx", None),
                "total_rounds_run": r.get("total_rounds_run", None),
                "best_val_ap": round(r.get("best_val_ap", float("nan")), 4),
            })
    df = pd.DataFrame(rows)
    n_not_converged = int((~df["converged"]).sum())
    if n_not_converged > 0:
        logger.warning(
            f"⚠️ {n_not_converged}/{len(df)} ران با converged=False ثبت شدند — "
            f"این باید صادقانه در متن مقاله (نه فقط پیوست) ذکر شود."
        )
    return df


# ==============================================================================
# مقایسهٔ آماری همهٔ واریانت‌ها در برابر baseline
# ==============================================================================
def run_statistical_comparisons(
    grouped_runs: Dict[str, List[dict]],
    baseline_name: str,
    metric: str = "ap",
    alpha: float = 0.05,
) -> Dict[str, object]:
    assert baseline_name in grouped_runs, f"❌ baseline '{baseline_name}' در نتایج نیست."

    variant_scores: Dict[str, List[float]] = {}
    for variant_name, runs in grouped_runs.items():
        # ترتیب seed باید یکسان بین واریانت‌ها باشد تا t-test زوجی معنادار بماند
        runs_sorted = sorted(runs, key=lambda r: r["seed"])
        variant_scores[variant_name] = [r["test_metrics"][metric] for r in runs_sorted]

    seed_counts = {v: len(s) for v, s in variant_scores.items()}
    if len(set(seed_counts.values())) > 1:
        logger.warning(
            f"⚠️ تعداد seed بین واریانت‌ها یکسان نیست {seed_counts} — مقایسهٔ "
            f"زوجی فقط روی زیرمجموعهٔ مشترک seedها معنادار است."
        )
        min_n = min(seed_counts.values())
        variant_scores = {v: s[:min_n] for v, s in variant_scores.items()}

    n_min = min((len(v) for v in variant_scores.values()), default=0)
    if n_min < 2:
        logger.warning(
            f"⚠️ آزمون‌های زوجی رد شد: حداقل تعداد seed = {n_min} (لازم: ۲). "
            f"این طبیعیِ دودآزمایی است؛ در ران کامل با ≥۳ seed اجرا می‌شود."
        )
        return {"skipped": True, "reason": f"n_seeds={n_min} < 2", "comparisons": {}}
    return compare_all_variants_vs_baseline(variant_scores, baseline_name, metric, alpha)


def run_ablation_equivalence_check(
    grouped_runs: Dict[str, List[dict]],
    variant_a: str,
    variant_b: str,
    equivalence_margin: float,
    metric: str = "ap",
) -> dict:
    """
    کاربرد اختصاصی: بررسی این‌که آیا نوآوری ۲ (Virtual Node) واقعاً تفاوت
    عملکردی معنادار ایجاد می‌کند یا نه — از طریق TOST بین
    FedGNN_SoftSelective_GCN (بدون virtual) و FedGNN_SoftSelective_Virtual_GCN.
    """
    assert variant_a in grouped_runs and variant_b in grouped_runs, "❌ هر دو واریانت باید در نتایج موجود باشند."
    scores_a = sorted(grouped_runs[variant_a], key=lambda r: r["seed"])
    scores_b = sorted(grouped_runs[variant_b], key=lambda r: r["seed"])
    n = min(len(scores_a), len(scores_b))

    a_vals = [r["test_metrics"][metric] for r in scores_a[:n]]
    b_vals = [r["test_metrics"][metric] for r in scores_b[:n]]
    result = tost_equivalence_test(a_vals, b_vals, equivalence_margin)
    return {
        "variant_a": variant_a, "variant_b": variant_b, "metric": metric,
        "tost_result": result,
    }


# ==============================================================================
# خروجی LaTeX — چسباندن مستقیم در مقاله
# ==============================================================================
def dataframe_to_latex_table(df: pd.DataFrame, caption: str, label: str) -> str:
    """تولید جدول LaTeX استاندارد booktabs — سازگار با اکثر تمپلیت‌های Q2 (IEEE/Elsevier)."""
    cols_to_show = ["variant", "ap_mean", "ap_std", "auc_mean", "auc_std", "f1_mean", "f1_std", "n_seeds"]
    subset = df[[c for c in cols_to_show if c in df.columns]].copy()
    latex_body = subset.to_latex(index=False, float_format="%.4f", escape=True)
    return (
        f"% جدول تولیدشده خودکار توسط analyze.py — قبل از استفاده در مقاله بازبینی دستی شود\n"
        f"\\begin{{table}}[htbp]\n\\centering\n\\caption{{{caption}}}\n\\label{{{label}}}\n"
        f"{latex_body}\n\\end{{table}}\n"
    )


# ==============================================================================
# ارکستریتور نهایی — یک تابع، خروجی کامل تحلیل
# ==============================================================================
def generate_full_report(
    artifacts_path: Path,
    output_dir: Path,
    baseline_name: str = "FedAvg_GCN",
    primary_metric: str = "ap",
) -> Dict[str, object]:
    output_dir.mkdir(parents=True, exist_ok=True)

    completed = load_completed_runs(artifacts_path)
    assert len(completed) > 0, "❌ هیچ رانِ completed برای تحلیل موجود نیست."
    grouped = group_runs_by_variant(completed)

    summary_df = build_summary_table(grouped)
    summary_df.to_csv(output_dir / "summary_table.csv", index=False)
    logger.info(f"✅ جدول خلاصه ذخیره شد: {output_dir / 'summary_table.csv'}")

    conv_df = convergence_report(grouped)
    conv_df.to_csv(output_dir / "convergence_report.csv", index=False)

    stats_result = None
    if baseline_name in grouped:
        stats_result = run_statistical_comparisons(grouped, baseline_name, primary_metric)
        with open(output_dir / "statistical_comparisons.json", "w", encoding="utf-8") as f:
            json.dump(
                {
                    "baseline": stats_result["baseline"],
                    "metric": stats_result["metric"],
                    "significant_after_holm": stats_result["significant_after_holm"],
                    "comparisons": [vars(c) for c in stats_result["comparisons"]],
                },
                f, ensure_ascii=False, indent=2, default=str,
            )
    else:
        logger.warning(f"⚠️ baseline '{baseline_name}' در نتایج نبود — مقایسهٔ آماری رد شد.")

    latex_table = dataframe_to_latex_table(
        summary_df, caption="Performance comparison across all variants (mean $\\pm$ std over seeds)",
        label="tab:main_results",
    )
    with open(output_dir / "main_results_table.tex", "w", encoding="utf-8") as f:
        f.write(latex_table)

    logger.info("🏁 تحلیل کامل شد؛ همهٔ خروجی‌ها در " + str(output_dir))
    return {
        "summary_table": summary_df,
        "convergence_report": conv_df,
        "statistical_comparison": stats_result,
        "output_dir": str(output_dir),
    }
