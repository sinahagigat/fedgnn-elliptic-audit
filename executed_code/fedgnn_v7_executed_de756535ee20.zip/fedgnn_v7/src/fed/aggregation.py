# -*- coding: utf-8 -*-
"""
aggregation.py — استراتژی‌های تجمیع سرور
==============================================================================
پیاده‌سازی همهٔ استراتژی‌های موردنیاز برای ۷ واریانت پروژه:

  • fedavg            → FedAvg_GCN / FedAvg_GAT      (خط پایه استاندارد)
  • fedprox           → تجمیع مثل FedAvg (جریمهٔ Prox در سمت client.py اعمال شد)
  • fedproto          → FedProto_GCN                 (+ تجمیع prototype سراسری)
  • fedgnn_hard        → FedGNN_Hard_GCN             (نوآوری ۳: انتخاب سخت top-k)
  • fedgnn_soft        → FedGNN_SoftSelective_*       (نوآوری ۳: وزن‌دهی نرم)

تجمیع گره‌های مجازی (نوآوری ۲) مستقل از الگوریتم بالا و صرفاً بر اساس
use_virtual_nodes انجام می‌شود.
"""

from __future__ import annotations

import logging
from typing import Dict, List, Optional

import numpy as np
import torch

from src.fed.client import ClientUpdate


def _align_devices(*tensors):
    """تانسورهای ورودی را روی یک دستگاه و dtype شناور مشترک هم‌تراز می‌کند.

    payload گره مجازی روی دستگاه مدل (cuda) ساخته می‌شود، اما وزن‌های کیفیت
    از یک لیست پایتونی و در نتیجه روی cpu. این تابع فقط دستگاه/dtype را
    یکسان می‌کند و هیچ محاسبهٔ آماری انجام نمی‌دهد.
    """
    ts = [x for x in tensors if isinstance(x, torch.Tensor)]
    if not ts:
        return tensors if len(tensors) != 1 else tensors[0]
    dev = next((x.device for x in ts if x.is_cuda), ts[0].device)
    fdt = next((x.dtype for x in ts if x.is_floating_point()), None)
    out = []
    for x in tensors:
        if isinstance(x, torch.Tensor):
            if fdt is not None and x.is_floating_point():
                x = x.to(device=dev, dtype=fdt)
            else:
                x = x.to(device=dev)
        out.append(x)
    return tuple(out) if len(out) != 1 else out[0]


logger = logging.getLogger("fedgnn.fed.aggregation")


# ==============================================================================
# تجمیع وزن مدل — FedAvg / FedProx (وزن‌دهی بر اساس num_train)
# ==============================================================================
def fedavg_aggregate(
    updates: List[ClientUpdate], selected_ids: Optional[List[int]] = None
) -> Dict[str, torch.Tensor]:
    """
    میانگین وزن‌دار state_dict کلاینت‌ها بر اساس تعداد نمونهٔ train.
    اگر selected_ids داده شود، فقط همان زیرمجموعه در تجمیع شرکت می‌کنند
    (پایهٔ مشترک برای hard_selective_aggregate).
    """
    chosen = [u for u in updates if selected_ids is None or u.client_id in selected_ids]
    if not chosen:
        raise ValueError("❌ هیچ کلاینتی برای تجمیع انتخاب نشده است.")

    total_n = sum(u.num_train for u in chosen)
    weights = [u.num_train / total_n for u in chosen]

    agg_state: Dict[str, torch.Tensor] = {}
    keys = chosen[0].state_dict.keys()
    for key in keys:
        stacked = torch.stack(
            [u.state_dict[key].float() * w for u, w in zip(chosen, weights)], dim=0
        )
        agg_state[key] = stacked.sum(dim=0).to(chosen[0].state_dict[key].dtype)

    return agg_state


# ==============================================================================
# تجمیع Prototype سراسری — FedProto / FedGNN_Hard / FedGNN_Soft
# ==============================================================================
def fedproto_aggregate_prototypes(
    updates: List[ClientUpdate], selected_ids: Optional[List[int]] = None
) -> Dict[int, torch.Tensor]:
    """
    میانگین وزن‌دار prototype هر کلاس بین کلاینت‌ها، با وزن برابر تعداد
    نمونهٔ همان کلاس نزد هر کلاینت (نه تعداد کل نمونهٔ کلاینت) — چون
    prototype کلاس ۱ فقط باید از کلاینت‌هایی که واقعاً نمونهٔ کلاس ۱
    دیده‌اند تأثیر بگیرد.
    """
    chosen = [u for u in updates if selected_ids is None or u.client_id in selected_ids]
    class_sums: Dict[int, torch.Tensor] = {}
    class_weight_totals: Dict[int, float] = {}

    for u in chosen:
        for c, proto in u.local_prototypes.items():
            n_c = u.class_counts.get(c, 0)
            if n_c == 0:
                continue
            if c not in class_sums:
                class_sums[c] = proto.clone().float() * n_c
                class_weight_totals[c] = float(n_c)
            else:
                class_sums[c] += proto.float() * n_c
                class_weight_totals[c] += float(n_c)

    global_prototypes = {
        c: (class_sums[c] / class_weight_totals[c])
        for c in class_sums
        if class_weight_totals[c] > 0
    }
    return global_prototypes


# ==============================================================================
# نوآوری ۳ — Hard-Selective Aggregation
# ==============================================================================
def hard_selective_aggregate(
    updates: List[ClientUpdate], top_k_ratio: float
) -> Dict[str, torch.Tensor]:
    """
    انتخاب سخت: فقط top-k کلاینت بر اساس selection_score در تجمیع شرکت
    می‌کنند (کلاینت‌های ضعیف/نویزی کاملاً کنار گذاشته می‌شوند). این نسخهٔ
    «سخت» نوآوری ۳ است — نسخهٔ «نرم» در soft_selective_aggregate.

    Args:
        top_k_ratio: نسبت کلاینت‌های نگه‌داشته‌شده (مثلاً 0.5 یعنی نیمهٔ بالا).
    """
    n_keep = max(1, int(round(len(updates) * top_k_ratio)))
    sorted_updates = sorted(updates, key=lambda u: u.selection_score, reverse=True)
    selected_ids = [u.client_id for u in sorted_updates[:n_keep]]

    logger.info(
        f"🎯 Hard-Selective: {n_keep}/{len(updates)} کلاینت انتخاب شدند "
        f"(scores: {[round(u.selection_score, 3) for u in sorted_updates]})"
    )
    return fedavg_aggregate(updates, selected_ids=selected_ids)


# ==============================================================================
# نوآوری ۳ — Soft-Selective Aggregation
# ==============================================================================
def soft_selective_aggregate(
    updates: List[ClientUpdate], temperature: float
) -> Dict[str, torch.Tensor]:
    """
    وزن‌دهی نرم: به‌جای حذف کامل کلاینت‌های ضعیف، وزن آن‌ها در تجمیع با
    softmax(selection_score / temperature) کاهش می‌یابد ولی صفر نمی‌شود —
    این نسخهٔ اصلی نوآوری ۳ (FedGNN_SoftSelective_*) است که ادعای اصلی
    مقاله را تشکیل می‌دهد: حفظ سهم همهٔ کلاینت‌ها (بدون طرد کامل، که به
    عدالت فدرال آسیب می‌زند) درحالی‌که تأثیر کلاینت‌های کم‌کیفیت مهار می‌شود.

    وزن نهایی هر کلاینت = softmax(score/T) ⊙ (num_train / sum(num_train))
    نرمال‌شده مجدداً به مجموع ۱ — یعنی هم کیفیت (score) و هم حجم داده
    (num_train) هر دو در تصمیم دخیل‌اند.
    """
    scores = np.array([u.selection_score for u in updates], dtype=np.float64)
    scores_scaled = scores / max(temperature, 1e-8)
    scores_scaled -= scores_scaled.max()  # پایداری عددی softmax
    soft_weights = np.exp(scores_scaled)
    soft_weights /= soft_weights.sum()

    data_weights = np.array([u.num_train for u in updates], dtype=np.float64)
    data_weights /= data_weights.sum()

    combined = soft_weights * data_weights
    combined /= combined.sum()

    logger.info(
        f"🎯 Soft-Selective: وزن نهایی کلاینت‌ها = "
        f"{[round(w, 4) for w in combined.tolist()]}"
    )

    agg_state: Dict[str, torch.Tensor] = {}
    keys = updates[0].state_dict.keys()
    for key in keys:
        stacked = torch.stack(
            [u.state_dict[key].float() * w for u, w in zip(updates, combined)], dim=0
        )
        agg_state[key] = stacked.sum(dim=0).to(updates[0].state_dict[key].dtype)

    return agg_state


# ==============================================================================
# تجمیع payload گره‌های مجازی (نوآوری ۲) — مستقل از الگوریتم اصلی
# ==============================================================================
def aggregate_virtual_payloads(
    updates: List[ClientUpdate],
) -> Optional[torch.Tensor]:
    """
    میانگین‌گیری ساده از payload خام مرزی همهٔ کلاینت‌ها (وزن‌دهی با
    boundary_degree هر کلاینت) و بازگرداندن یک بردار مرجع سراسری واحد که
    در راند بعد به همهٔ کلاینت‌ها broadcast می‌شود (client.set_virtual_reference).

    توجه: چون فقط 'mean' آماره تجمیعی سطح‌ کلاینت است (نه دادهٔ خام)، این
    عملیات دقیقاً هم‌ارز یک secure-aggregation سبک روی میانگین‌هاست.
    """
    payloads = [u.virtual_payload for u in updates if u.virtual_payload is not None]
    if not payloads:
        return None

    weights = torch.tensor(
        [max(p["boundary_degree"].item(), 1e-6) for p in payloads]
    )
    weights = weights / weights.sum()

    means = torch.stack([p["mean"] for p in payloads], dim=0)  # [n_clients, F]
    means, weights = _align_devices(means, weights)
    global_mean = (means * weights.unsqueeze(1)).sum(dim=0)

    return global_mean
