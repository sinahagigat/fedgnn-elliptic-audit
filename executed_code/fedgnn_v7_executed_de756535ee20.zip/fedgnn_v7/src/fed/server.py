# -*- coding: utf-8 -*-
"""
server.py — اورکستریتور سمت سرور برای یک واریانت/seed
==============================================================================
حلقهٔ اصلی آموزش فدرال: broadcast وزن سراسری + prototype + virtual-ref →
جمع‌آوری ClientUpdate از همهٔ کلاینت‌ها → تجمیع طبق fed_cfg.algorithm →
انتخاب بهترین چک‌پوینت بر اساس val_ap → تشخیص همگرایی (converged flag).

خروجی این ماژول مستقیماً به src/train.py (بلوک ۶) داده می‌شود تا روی
داده‌های test نهایی ارزیابی شود.
"""

from __future__ import annotations

import copy
import logging
from dataclasses import dataclass, field
from typing import Dict, List, Optional

import numpy as np
import torch

from src.config import FedConfig
from src.fed.client import FederatedClient, ClientUpdate
from src.fed.aggregation import (
    fedavg_aggregate,
    fedproto_aggregate_prototypes,
    hard_selective_aggregate,
    soft_selective_aggregate,
    aggregate_virtual_payloads,
)

logger = logging.getLogger("fedgnn.fed.server")


# ==============================================================================
# رکورد تاریخچهٔ یک راند — برای گزارش‌دهی و تشخیص همگرایی
# ==============================================================================
@dataclass
class RoundRecord:
    round_idx: int
    avg_train_loss: float
    avg_val_ap: float
    avg_val_auc: float
    per_client_val_ap: Dict[int, float]
    selection_scores: Optional[Dict[int, float]] = None


# ==============================================================================
# سرور فدرال
# ==============================================================================
class FederatedServer:
    """
    اورکستریتور یک آزمایش کامل (یک واریانت روی یک seed): مدیریت وضعیت
    سراسری (وزن مدل، prototype‌ها، مرجع گره مجازی)، اجرای num_rounds
    راند، انتخاب بهترین چک‌پوینت طبق val_ap، و تشخیص converged بر اساس
    عدم بهبود معنادار در یک پنجرهٔ صبر (patience).
    """

    def __init__(
        self,
        clients: List[FederatedClient],
        initial_state_dict: Dict[str, torch.Tensor],
        fed_cfg: FedConfig,
    ):
        self.clients = clients
        self.fed_cfg = fed_cfg

        # وضعیت سراسری — نقطهٔ واحد حقیقت طی کل آموزش فدرال
        self.global_state_dict: Dict[str, torch.Tensor] = copy.deepcopy(initial_state_dict)
        self.global_prototypes: Optional[Dict[int, torch.Tensor]] = None
        self.global_virtual_ref: Optional[torch.Tensor] = None

        # بهترین چک‌پوینت دیده‌شده تا این لحظه (بر اساس میانگین val_ap کلاینت‌ها)
        self.best_state_dict: Dict[str, torch.Tensor] = copy.deepcopy(initial_state_dict)
        self.best_val_ap: float = -1.0
        self.best_round_idx: int = -1

        self.history: List[RoundRecord] = []
        self._rounds_without_improve: int = 0
        self.converged: bool = False

    # -------------------------------------------------------------- #
    def _select_aggregation_fn(self, updates: List[ClientUpdate]) -> Dict[str, torch.Tensor]:
        """انتخاب استراتژی تجمیع وزن مدل بر اساس fed_cfg.algorithm."""
        algo = self.fed_cfg.algorithm

        if algo == "fedgnn_hard":
            return hard_selective_aggregate(updates, top_k_ratio=self.fed_cfg.top_k_ratio)
        elif algo == "fedgnn_soft":
            return soft_selective_aggregate(updates, temperature=self.fed_cfg.aggregation_temperature)
        elif algo in ("fedavg", "fedprox", "fedproto"):
            return fedavg_aggregate(updates)
        else:
            raise ValueError(f"❌ الگوریتم تجمیع ناشناخته: {algo}")

    # -------------------------------------------------------------- #
    def run_round(self, round_idx: int) -> RoundRecord:
        """
        اجرای یک راند کامل فدرال:
          1) broadcast وضعیت سراسری جاری به همهٔ کلاینت‌ها + local_train
          2) تجمیع وزن مدل طبق الگوریتم منتخب
          3) تجمیع prototype سراسری (در صورت فعال بودن نوآوری ۱)
          4) تجمیع/به‌روزرسانی مرجع گره مجازی (نوآوری ۲)
          5) ثبت تاریخچه + به‌روزرسانی بهترین چک‌پوینت
        """
        updates: List[ClientUpdate] = []
        for client in self.clients:
            update = client.local_train(
                global_state_dict=self.global_state_dict,
                global_prototypes=self.global_prototypes,
                external_virtual_ref=self.global_virtual_ref,
                round_idx=round_idx,
            )
            updates.append(update)

        # --- تجمیع وزن مدل (Fail-fast: اگر هیچ کلاینتی آپدیت نداد، خطا) ---
        assert len(updates) > 0, "❌ هیچ ClientUpdate ای از کلاینت‌ها دریافت نشد."
        self.global_state_dict = self._select_aggregation_fn(updates)

        # --- تجمیع prototype سراسری (نوآوری ۱) ---
        if self.fed_cfg.algorithm in ("fedproto", "fedgnn_hard", "fedgnn_soft"):
            self.global_prototypes = fedproto_aggregate_prototypes(updates)

        # --- تجمیع مرجع گره مجازی (نوآوری ۲) — مستقل از الگوریتم اصلی ---
        if self.fed_cfg.use_virtual_nodes:
            new_ref = aggregate_virtual_payloads(updates)
            if new_ref is not None:
                self.global_virtual_ref = new_ref

        # --- تجمیع متریک‌ها برای گزارش این راند ---
        avg_train_loss = float(np.mean([u.metrics["train_loss"] for u in updates]))
        avg_val_ap = float(np.mean([u.metrics["val_ap"] for u in updates]))
        avg_val_auc = float(np.mean([u.metrics["val_auc"] for u in updates]))
        per_client_val_ap = {u.client_id: u.metrics["val_ap"] for u in updates}
        selection_scores = (
            {u.client_id: u.selection_score for u in updates}
            if self.fed_cfg.algorithm in ("fedgnn_hard", "fedgnn_soft")
            else None
        )

        record = RoundRecord(
            round_idx=round_idx,
            avg_train_loss=avg_train_loss,
            avg_val_ap=avg_val_ap,
            avg_val_auc=avg_val_auc,
            per_client_val_ap=per_client_val_ap,
            selection_scores=selection_scores,
        )
        self.history.append(record)

        # --- به‌روزرسانی بهترین چک‌پوینت (معیار تک‌نقطه‌ای val_ap) ---
        improved = avg_val_ap > self.best_val_ap + self.fed_cfg.min_delta
        if improved:
            self.best_val_ap = avg_val_ap
            self.best_state_dict = copy.deepcopy(self.global_state_dict)
            self.best_round_idx = round_idx
            self._rounds_without_improve = 0
        else:
            self._rounds_without_improve += 1

        # --- تشخیص همگرایی (converged flag) ---
        if self._rounds_without_improve >= self.fed_cfg.patience:
            self.converged = True

        logger.info(
            f"🌐 سرور | راند {round_idx}/{self.fed_cfg.num_rounds} | "
            f"train_loss={avg_train_loss:.4f} | val_ap={avg_val_ap:.4f} | "
            f"best_val_ap={self.best_val_ap:.4f} @ راند {self.best_round_idx} | "
            f"صبر={self._rounds_without_improve}/{self.fed_cfg.patience} | "
            f"converged={self.converged}"
        )

        return record

    # -------------------------------------------------------------- #
    def run(self) -> Dict[str, object]:
        """
        اجرای کامل num_rounds راند با پشتیبانی از early-stopping طبق
        patience. اگر converged=True زودتر رخ دهد، حلقه متوقف می‌شود اما
        این وضعیت صریحاً در خروجی گزارش می‌شود (نه پنهان‌کاری در نتایج).
        """
        for round_idx in range(1, self.fed_cfg.num_rounds + 1):
            self.run_round(round_idx)
            if self.converged and self.fed_cfg.early_stop_enabled:
                logger.info(
                    f"⏹️ توقف زودهنگام در راند {round_idx} — عدم بهبود val_ap "
                    f"طی {self.fed_cfg.patience} راند متوالی."
                )
                break

        return {
            "best_state_dict": self.best_state_dict,
            "best_val_ap": self.best_val_ap,
            "best_round_idx": self.best_round_idx,
            "converged": self.converged,
            "total_rounds_run": len(self.history),
            "global_prototypes": self.global_prototypes,
            "history": self.history,
        }

    # -------------------------------------------------------------- #
    def get_best_model_state(self) -> Dict[str, torch.Tensor]:
        """بازگرداندن بهترین وزن‌های یافت‌شده در کل آموزش فدرال."""
        return self.best_state_dict
