# -*- coding: utf-8 -*-
"""
privacy.py — لایهٔ حریم خصوصی افتراقی (Differential Privacy) اختیاری
==============================================================================
⚠️ صداقت علمی: مکانیزم پیاده‌سازی‌شده در این ماژول یک تقریب استاندارد
Gaussian Mechanism با کامپوزیشن سادهٔ (naive/basic composition) بودجهٔ
epsilon است — نه یک اکانتنت دقیق مبتنی بر Rényi-DP یا Moments Accountant.
بنابراین هر مقدار epsilon گزارش‌شده در artifacts باید در مقاله به‌عنوان
«تخمین تقریبی برای پایش نسبی نویز» ذکر شود، نه یک ضمانت (ε,δ)-DP رسمی و
اثبات‌شده. این ماژول کاملاً اختیاری است: اگر PrivacyConfig.enabled=False
باشد، هیچ نویزی اعمال نمی‌شود و رفتار سیستم دقیقاً معادل عدم وجود این
ماژول است (Graceful Degradation).

عملکردها:
  1) clip_tensor / clip_state_dict     — Clipping نُرم L2 (پیش‌نیاز نویز)
  2) add_gaussian_noise                — تزریق نویز گاوسی کالیبره‌شده
  3) privatize_prototype               — حریم خصوصی روی prototype محلی
  4) privatize_virtual_payload         — حریم خصوصی روی payload مرزی
  5) privatize_model_update            — حریم خصوصی روی دلتای وزن مدل (DP-FedAvg سبک)
  6) PrivacyAccountant                 — پیگیری بودجهٔ epsilon مصرف‌شده
"""

from __future__ import annotations

import logging
import math
from dataclasses import dataclass, field
from typing import Dict, Optional

import torch

from src.config import PrivacyConfig

logger = logging.getLogger("fedgnn.fed.privacy")


# ==============================================================================
# Clipping — پیش‌نیاز اجباری هر مکانیزم نویز کالیبره‌شده
# ==============================================================================
def clip_tensor(tensor: torch.Tensor, max_norm: float) -> torch.Tensor:
    """Clip کردن نُرم L2 یک تنسور دلخواه به سقف max_norm."""
    norm = torch.norm(tensor.detach(), p=2)
    if norm <= max_norm or norm == 0:
        return tensor
    return tensor * (max_norm / (norm + 1e-8))


def clip_state_dict(
    state_dict: Dict[str, torch.Tensor], max_norm: float
) -> Dict[str, torch.Tensor]:
    """
    Clip کردن نُرم L2 *کل* بردار مسطح‌شدهٔ پارامترها (نه لایه‌به‌لایه) —
    این معیار استاندارد DP-SGD/DP-FedAvg برای کنترل حساسیت کل به‌روزرسانی است.
    """
    flat = torch.cat([v.flatten().float() for v in state_dict.values()])
    total_norm = torch.norm(flat, p=2)
    if total_norm <= max_norm or total_norm == 0:
        return state_dict

    scale = max_norm / (total_norm + 1e-8)
    return {k: v * scale for k, v in state_dict.items()}


# ==============================================================================
# تزریق نویز گاوسی
# ==============================================================================
def add_gaussian_noise(
    tensor: torch.Tensor,
    noise_std: float,
    generator: Optional[torch.Generator] = None,
) -> torch.Tensor:
    """افزودن نویز گاوسی i.i.d با انحراف‌معیار noise_std به یک تنسور."""
    if noise_std <= 0:
        return tensor
    noise = torch.randn(tensor.shape, generator=generator, device=tensor.device) * noise_std
    return tensor + noise


# ==============================================================================
# حریم خصوصی روی prototype محلی (قبل از ارسال به سرور)
# ==============================================================================
def privatize_prototype(
    prototype: torch.Tensor,
    privacy_cfg: PrivacyConfig,
    generator: Optional[torch.Generator] = None,
) -> torch.Tensor:
    """
    Clip + نویز روی بردار prototype یک کلاس، پیش از خروج از کلاینت. چون
    prototype از قبل یک آمارهٔ تجمیعی (میانگین embedding کلاس) است — نه
    دادهٔ خام — حساسیت آن به‌طور طبیعی محدود است؛ Clipping فقط برای
    کالیبراسیون نویز لازم است.
    """
    if not privacy_cfg.enabled:
        return prototype
    clipped = clip_tensor(prototype, privacy_cfg.clip_norm)
    noise_std = privacy_cfg.clip_norm * privacy_cfg.noise_multiplier
    return add_gaussian_noise(clipped, noise_std, generator)


# ==============================================================================
# حریم خصوصی روی payload گره‌های مجازی (نوآوری ۲)
# ==============================================================================
def privatize_virtual_payload(
    payload: Dict[str, torch.Tensor],
    privacy_cfg: PrivacyConfig,
    generator: Optional[torch.Generator] = None,
) -> Dict[str, torch.Tensor]:
    """
    اعمال حریم خصوصی روی بردار 'mean' payload مرزی (کلید 'boundary_degree'
    بدون نویز باقی می‌ماند چون فقط یک عدد صحیح جمعی است و برای وزن‌دهی
    aggregate_virtual_payloads لازم است — نشتی اطلاعاتی معنادار ندارد).
    """
    if not privacy_cfg.enabled:
        return payload
    noised = dict(payload)
    noised["mean"] = privatize_prototype(payload["mean"], privacy_cfg, generator)
    return noised


# ==============================================================================
# حریم خصوصی روی دلتای وزن مدل (سبک DP-FedAvg) — اختیاری، هزینه‌بر روی دقت
# ==============================================================================
def privatize_model_update(
    local_state: Dict[str, torch.Tensor],
    global_state: Dict[str, torch.Tensor],
    privacy_cfg: PrivacyConfig,
    generator: Optional[torch.Generator] = None,
) -> Dict[str, torch.Tensor]:
    """
    محاسبهٔ دلتای (وزن محلی - وزن سراسری) → Clip نُرم کل → نویز گاوسی →
    بازسازی وزن نهایی محلی = وزن سراسری + دلتای نویزی. این دقیقاً معادل
    DP-FedAvg (McMahan et al., 2018) در سطح هر کلاینت است.

    ⚠️ توجه: این تابع به‌طور پیش‌فرض در واریانت‌های اصلی مقاله فعال نیست
    (privacy_cfg.enabled=False) چون هزینهٔ دقت آن روی دادهٔ کوچک/نامتوازن
    Elliptic قابل‌توجه است؛ صرفاً برای تحلیل حساسیت حریم خصوصی (که در
    صورت نیاز به‌عنوان یک بخش جانبی در مقاله گزارش می‌شود) نگه داشته شده.
    """
    if not privacy_cfg.enabled:
        return local_state

    delta = {k: local_state[k].float() - global_state[k].float() for k in local_state}
    clipped_delta = clip_state_dict(delta, privacy_cfg.clip_norm)

    noise_std = privacy_cfg.clip_norm * privacy_cfg.noise_multiplier
    noised_delta = {
        k: add_gaussian_noise(v, noise_std, generator) for k, v in clipped_delta.items()
    }

    return {
        k: (global_state[k].float() + noised_delta[k]).to(local_state[k].dtype)
        for k in local_state
    }


# ==============================================================================
# پیگیری بودجهٔ epsilon (Naive Composition) — فقط برای پایش نسبی، نه ضمانت رسمی
# ==============================================================================
@dataclass
class PrivacyAccountant:
    """
    پیگیری تقریبی epsilon مصرف‌شده طی راندهای متوالی با فرض کامپوزیشن
    سادهٔ (basic composition): ε_total ≈ Σ ε_round. این تخمین محافظه‌کارانه
    (بدتر از واقعیت) است و عمداً پیچیده‌تر (مثل RDP accountant) نشده تا
    ادعای نادرستی در مقاله دربارهٔ دقت آن مطرح نشود.
    """
    delta: float
    epsilon_per_round: float = field(default=0.0, init=False)
    total_epsilon_consumed: float = field(default=0.0, init=False)
    rounds_accounted: int = field(default=0, init=False)

    def compute_epsilon_for_round(self, noise_multiplier: float) -> float:
        """
        فرمول تقریبی Gaussian mechanism: ε ≈ sqrt(2 * ln(1.25/δ)) / σ
        (σ = noise_multiplier). این رابطهٔ استاندارد (Dwork & Roth, 2014،
        Theorem 3.22) برای یک اعمال منفرد مکانیزم گاوسی است.
        """
        if noise_multiplier <= 0:
            return float("inf")  # بدون نویز یعنی بدون ضمانت DP
        eps = math.sqrt(2.0 * math.log(1.25 / self.delta)) / noise_multiplier
        return eps

    def record_round(self, noise_multiplier: float) -> float:
        eps_round = self.compute_epsilon_for_round(noise_multiplier)
        self.epsilon_per_round = eps_round
        self.total_epsilon_consumed += eps_round
        self.rounds_accounted += 1
        logger.debug(
            f"🔒 PrivacyAccountant | راند {self.rounds_accounted} | "
            f"ε_راند≈{eps_round:.4f} | ε_تجمعی≈{self.total_epsilon_consumed:.4f}"
        )
        return self.total_epsilon_consumed

    def summary(self) -> Dict[str, float]:
        return {
            "delta": self.delta,
            "epsilon_per_round_approx": self.epsilon_per_round,
            "total_epsilon_consumed_approx_naive_composition": self.total_epsilon_consumed,
            "rounds_accounted": self.rounds_accounted,
        }
