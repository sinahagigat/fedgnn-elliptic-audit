
# -*- coding: utf-8 -*-
"""
rust_ext — شتاب‌دهندهٔ اختیاری Rust برای محاسبهٔ گره‌های مرزی
==============================================================================
چرا این ماژول؟ حلقهٔ Python در federated_dataset._compute_boundary_info
روی گراف‌های بزرگ‌تر (خارج از Elliptic فعلی، برای future scaling) می‌تواند
گلوگاه شود. این بسته یک نقطهٔ توسعه فراهم می‌کند:

  1) تلاش برای import یک اکستنشن کامپایل‌شدهٔ Rust (PyO3) به نام
     `fedgnn_rust` — اگر نصب/کامپایل شده باشد (نیازی به آن در محیط
     Colab فعلی نیست).
  2) در صورت نبود آن، Graceful Degradation کامل به پیاده‌سازی numpy
     برداری‌شده در fallback.py — که برای اندازهٔ فعلی دیتاست Elliptic
     (~۴۶ هزار گره) کاملاً کافی و سریع است.

نتیجه: کد پروژه هرگز به‌خاطر نبود Rust توolchain کرش نمی‌کند؛ صرفاً یک
پیام لاگ اطلاعاتی می‌دهد.
"""

from __future__ import annotations

import logging

logger = logging.getLogger("fedgnn.rust_ext")

_BACKEND = "fallback"

try:
    import fedgnn_rust as _rust_backend  # type: ignore
    _BACKEND = "rust"
    logger.info("🦀 اکستنشن Rust (fedgnn_rust) بارگذاری شد — از بک‌اند سریع استفاده می‌شود.")
except ImportError:
    from src.rust_ext.fallback import compute_boundary_fast as _rust_backend_compute_boundary_fallback
    logger.info(
        "ℹ️ اکستنشن Rust یافت نشد؛ استفاده از fallback برداری‌شدهٔ numpy "
        "(کاملاً کافی برای اندازهٔ فعلی دیتاست)."
    )


def compute_boundary_fast(edge_index_np, assignment_np, num_clients: int):
    """
    رابط یکنواخت — چه Rust باشد چه fallback، همین امضا را دارد.

    Returns:
        boundary_degree: dict[global_node_idx -> int]
        neighbor_client_map: dict[global_node_idx -> set[int]]
    """
    if _BACKEND == "rust":
        return _rust_backend.compute_boundary(edge_index_np, assignment_np, num_clients)
    return _rust_backend_compute_boundary_fallback(edge_index_np, assignment_np, num_clients)


def get_active_backend() -> str:
    return _BACKEND
