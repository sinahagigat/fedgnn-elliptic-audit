# -*- coding: utf-8 -*-
"""
elliptic.py — بارگذاری و پیش‌پردازش دیتاست Elliptic Bitcoin Transaction Graph
==============================================================================
خروجی این ماژول یک شیء واحد torch_geometric.data.Data است که «حقیقت مطلق»
گراف سراسری محسوب می‌شود؛ تمام مراحل بعدی (پارتیشن فدرال، گره‌های مجازی،
آموزش) از همین شیء تغذیه می‌کنند.

نکات ضد نشتی (Anti-Leakage):
  1) اسکیلر ویژگی‌ها فقط روی گره‌های TRAIN (بر اساس گام زمانی) fit می‌شود.
  2) split_mode="temporal" پیش‌فرض است: گام‌های 1..34 → train، 35..39 → val،
     40..49 → test. این رایج‌ترین و دفاع‌پذیرترین پروتوکل در مقالات
     Elliptic است و از نشتی زمانی جلوگیری می‌کند.
  3) اگر include_timestep_as_feature=False (پیش‌فرض)، ستون گام زمانی از
     بردار ویژگی حذف می‌شود تا مدل نتواند مستقیماً زمان را حدس بزند.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Optional, Tuple

import numpy as np
import pandas as pd
import torch
from sklearn.preprocessing import MinMaxScaler, StandardScaler
from torch_geometric.data import Data
from torch_geometric.utils import remove_self_loops, coalesce, to_undirected

from src.config import DataConfig

logger = logging.getLogger("fedgnn.data.elliptic")


# ==============================================================================
# ۱) بارگذاری فایل‌های خام
# ==============================================================================
def _load_raw_csvs(cfg: DataConfig) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """
    بارگذاری سه فایل استاندارد Elliptic.

    ساختار elliptic_txs_features.csv: بدون هدر؛ ستون ۰ = txId، ستون ۱ = time_step،
    ستون‌های ۲..۱۶۶ = ۱۶۵ ویژگی (۹۳ محلی + ۷۲ تجمعی).
    ساختار elliptic_txs_classes.csv: هدر txId,class با مقادیر {"1","2","unknown"}.
    ساختار elliptic_txs_edgelist.csv: هدر txId1,txId2 (یال جهت‌دار).
    """
    root = Path(cfg.root)
    feat_path = root / cfg.file_features
    class_path = root / cfg.file_classes
    edge_path = root / cfg.file_edgelist

    for p in (feat_path, class_path, edge_path):
        if not p.exists():
            raise FileNotFoundError(
                f"❌ فایل داده یافت نشد: {p}\n"
                f"لطفاً فایل‌های خام Elliptic را در مسیر '{cfg.root}' قرار دهید."
            )

    features_df = pd.read_csv(feat_path, header=None)
    n_feat_cols = features_df.shape[1] - 2
    feat_cols = [f"feat_{i}" for i in range(n_feat_cols)]
    features_df.columns = ["txId", "time_step"] + feat_cols

    classes_df = pd.read_csv(class_path)
    classes_df.columns = [c.strip().lower() for c in classes_df.columns]
    if "txid" in classes_df.columns:
        classes_df = classes_df.rename(columns={"txid": "txId", "class": "class"})

    edges_df = pd.read_csv(edge_path)
    edges_df.columns = [c.strip() for c in edges_df.columns]
    # نام‌های ستون ممکن است txId1/txId2 یا txId1,txId2 با فاصله باشند
    rename_map = {}
    for c in edges_df.columns:
        cl = c.lower()
        if cl in ("txid1", "tx_id1", "source"):
            rename_map[c] = "txId1"
        elif cl in ("txid2", "tx_id2", "target"):
            rename_map[c] = "txId2"
    edges_df = edges_df.rename(columns=rename_map)

    logger.info(
        f"بارگذاری خام: {len(features_df):,} گره (کل) | "
        f"{len(classes_df):,} برچسب | {len(edges_df):,} یال جهت‌دار (کل)"
    )
    return features_df, classes_df, edges_df


# ==============================================================================
# ۲) فیلتر به گره‌های برچسب‌دار + بازنمایه‌سازی
# ==============================================================================
def _filter_and_reindex(
    features_df: pd.DataFrame,
    classes_df: pd.DataFrame,
    edges_df: pd.DataFrame,
    cfg: DataConfig,
) -> Tuple[pd.DataFrame, pd.DataFrame, dict]:
    """
    ادغام ویژگی‌ها با برچسب‌ها، فیلتر گره‌های unknown (در صورت
    keep_labeled_only=True) و ساخت نگاشت txId → اندیس صفر-پایه.
    """
    merged = features_df.merge(classes_df, on="txId", how="left")
    merged["class"] = merged["class"].astype(str)

    if cfg.keep_labeled_only:
        mask = merged["class"] != cfg.unknown_label_raw
        merged = merged[mask].reset_index(drop=True)

    # نگاشت برچسب خام → دودویی (1=illicit/مثبت، 0=licit/منفی)
    label_map = {cfg.positive_label_raw: 1, cfg.negative_label_raw: 0}
    merged["y"] = merged["class"].map(label_map)
    if merged["y"].isna().any():
        n_bad = int(merged["y"].isna().sum())
        logger.warning(f"⚠️ {n_bad} گره با برچسب نامشخص یافت شد؛ حذف می‌شوند.")
        merged = merged.dropna(subset=["y"]).reset_index(drop=True)
    merged["y"] = merged["y"].astype(int)

    # نگاشت txId → اندیس جدید صفر-پایه
    tx_to_idx = {tx: i for i, tx in enumerate(merged["txId"].values)}

    # فیلتر یال‌ها: هر دو سر یال باید در مجموعهٔ گره‌های نگه‌داشته‌شده باشند
    valid_tx = set(tx_to_idx.keys())
    edges_filtered = edges_df[
        edges_df["txId1"].isin(valid_tx) & edges_df["txId2"].isin(valid_tx)
    ].copy()

    edges_filtered["src"] = edges_filtered["txId1"].map(tx_to_idx)
    edges_filtered["dst"] = edges_filtered["txId2"].map(tx_to_idx)

    stats = {
        "num_nodes": len(merged),
        "num_edges_directed_pre_undirected": len(edges_filtered),
        "positive_rate": float(merged["y"].mean()),
    }
    return merged, edges_filtered, stats


# ==============================================================================
# ۳) ساخت گراف نهایی (Data)
# ==============================================================================
def _build_edge_index(edges_filtered: pd.DataFrame, num_nodes: int, cfg: DataConfig) -> torch.Tensor:
    """ساخت edge_index نهایی با اعمال make_undirected و remove_self_loops."""
    src = torch.tensor(edges_filtered["src"].values, dtype=torch.long)
    dst = torch.tensor(edges_filtered["dst"].values, dtype=torch.long)
    edge_index = torch.stack([src, dst], dim=0)

    if cfg.remove_self_loops:
        edge_index, _ = remove_self_loops(edge_index)

    if cfg.make_undirected:
        edge_index = to_undirected(edge_index, num_nodes=num_nodes)
    else:
        edge_index = coalesce(edge_index, num_nodes=num_nodes)

    return edge_index


def _select_feature_columns(merged: pd.DataFrame, cfg: DataConfig) -> list:
    """
    انتخاب ستون‌های ویژگی بر اساس ablation:
      - use_local_features: ۹۳ ویژگی محلی (feat_0 .. feat_92)
      - use_aggregated_features: ۷۲ ویژگی تجمعی (feat_93 .. feat_164)
      - include_timestep_as_feature: افزودن گام زمانی به‌عنوان ویژگی
    (تعداد دقیق مرزهای local/aggregated مطابق مقالهٔ اصلی Elliptic است.)
    """
    all_feat_cols = [c for c in merged.columns if c.startswith("feat_")]
    n_local = 93
    local_cols = all_feat_cols[:n_local]
    agg_cols = all_feat_cols[n_local:]

    selected = []
    if cfg.use_local_features:
        selected += local_cols
    if cfg.use_aggregated_features:
        selected += agg_cols
    if not selected:
        raise ValueError("❌ حداقل یکی از use_local_features/use_aggregated_features باید True باشد.")

    if cfg.include_timestep_as_feature:
        selected = ["time_step"] + selected

    return selected


def _make_temporal_masks(time_step: np.ndarray, cfg: DataConfig) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    train_mask = time_step <= cfg.temporal_train_end
    val_mask = (time_step > cfg.temporal_train_end) & (time_step <= cfg.temporal_val_end)
    test_mask = time_step > cfg.temporal_val_end
    return train_mask, val_mask, test_mask


def _make_random_masks(n: int, ratios: Tuple[float, float, float], seed: int) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    rng = np.random.RandomState(seed)
    perm = rng.permutation(n)
    n_train = int(ratios[0] * n)
    n_val = int(ratios[1] * n)
    train_idx = perm[:n_train]
    val_idx = perm[n_train:n_train + n_val]
    test_idx = perm[n_train + n_val:]
    train_mask = np.zeros(n, dtype=bool); train_mask[train_idx] = True
    val_mask = np.zeros(n, dtype=bool); val_mask[val_idx] = True
    test_mask = np.zeros(n, dtype=bool); test_mask[test_idx] = True
    return train_mask, val_mask, test_mask


def _scale_features(x: np.ndarray, train_mask: np.ndarray, cfg: DataConfig) -> np.ndarray:
    """
    نکتهٔ ضد نشتی حیاتی: اسکیلر فقط روی x[train_mask] فیت می‌شود، سپس
    روی کل ماتریس transform اعمال می‌شود. این کار جلوگیری می‌کند آماره‌های
    val/test (که در دنیای واقعی «آینده» هستند) در نرمال‌سازی train دخالت کنند.
    """
    if cfg.feature_scaling == "none":
        return x

    scaler = StandardScaler() if cfg.feature_scaling == "standard" else MinMaxScaler()
    fit_mask = train_mask if cfg.fit_scaler_on_train_only else np.ones(len(x), dtype=bool)

    scaler.fit(x[fit_mask])
    return scaler.transform(x)


def _run_sanity_assertions(stats: dict, cfg: DataConfig) -> None:
    """Fail-fast: اگر اعداد بارگذاری‌شده با انتظارات ثبت‌شده در config فاصلهٔ
    زیادی داشته باشند، خطا در همین‌جا کشف می‌شود، نه ۴۰ دقیقه بعد در یک
    متریک عجیب."""
    def _check(name, actual, expected, tol):
        if expected is None:
            return
        rel_diff = abs(actual - expected) / max(abs(expected), 1e-9)
        if rel_diff > tol:
            logger.warning(
                f"⚠️ عدم تطابق '{name}': مقدار واقعی={actual}, انتظار={expected} "
                f"(اختلاف نسبی={rel_diff:.3f} > تلورانس={tol})."
            )
        else:
            logger.info(f"✓ سلامت '{name}' تأیید شد: {actual} (انتظار≈{expected}).")

    _check("num_nodes", stats["num_nodes"], cfg.expected_num_nodes, cfg.assert_tolerance)
    _check("num_edges_directed", stats["num_edges_directed_pre_undirected"],
           cfg.expected_num_edges_directed, cfg.assert_tolerance)
    _check("positive_rate", stats["positive_rate"], cfg.expected_positive_rate, cfg.assert_tolerance)


# ==============================================================================
# ۴) نقطهٔ ورود عمومی
# ==============================================================================
def load_elliptic_graph(cfg: DataConfig, seed: int = 42) -> Data:
    """
    بارگذاری کامل، پیش‌پردازش و ساخت گراف سراسری Elliptic.

    Returns:
        torch_geometric.data.Data با فیلدهای:
          x            : [N, F] ماتریس ویژگی (اسکیل‌شده)
          y             : [N] برچسب دودویی (1=illicit)
          edge_index    : [2, E] یال‌های نامرتب‌شده (پس از make_undirected)
          time_step     : [N] گام زمانی هر تراکنش
          train_mask/val_mask/test_mask : [N] بولی
          tx_id         : [N] شناسهٔ اصلی تراکنش (برای ردیابی/دیباگ)
          meta          : dict آمار توصیفی گراف
    """
    features_df, classes_df, edges_df = _load_raw_csvs(cfg)
    merged, edges_filtered, stats = _filter_and_reindex(features_df, classes_df, edges_df, cfg)

    n = len(merged)
    time_step = merged["time_step"].values.astype(np.int64)
    y = merged["y"].values.astype(np.int64)
    tx_id = merged["txId"].values

    feat_cols = _select_feature_columns(merged, cfg)
    x_raw = merged[feat_cols].values.astype(np.float32)

    if cfg.split_mode == "temporal":
        train_mask, val_mask, test_mask = _make_temporal_masks(time_step, cfg)
    elif cfg.split_mode == "random_stratified":
        train_mask, val_mask, test_mask = _make_random_masks(n, cfg.random_split_ratios, seed)
    else:
        raise ValueError(f"split_mode ناشناخته: {cfg.split_mode}")

    if train_mask.sum() == 0:
        raise RuntimeError("❌ مجموعهٔ train خالی است؛ مرزهای temporal_train_end را بررسی کنید.")

    x_scaled = _scale_features(x_raw, train_mask, cfg)

    edge_index = _build_edge_index(edges_filtered, num_nodes=n, cfg=cfg)

    data = Data(
        x=torch.tensor(x_scaled, dtype=torch.float32),
        y=torch.tensor(y, dtype=torch.long),
        edge_index=edge_index,
    )
    data.time_step = torch.tensor(time_step, dtype=torch.long)
    data.train_mask = torch.tensor(train_mask, dtype=torch.bool)
    data.val_mask = torch.tensor(val_mask, dtype=torch.bool)
    data.test_mask = torch.tensor(test_mask, dtype=torch.bool)
    data.tx_id = tx_id  # numpy array نگه داشته می‌شود؛ tensor نیست

    data.meta = {
        "num_nodes": n,
        "num_edges_directed_pre_undirected": stats["num_edges_directed_pre_undirected"],
        "num_edges_final": int(edge_index.shape[1]),
        "positive_rate": stats["positive_rate"],
        "positive_rate_train": float(y[train_mask].mean()),
        "positive_rate_val": float(y[val_mask].mean()) if val_mask.sum() else float("nan"),
        "positive_rate_test": float(y[test_mask].mean()) if test_mask.sum() else float("nan"),
        "n_train": int(train_mask.sum()),
        "n_val": int(val_mask.sum()),
        "n_test": int(test_mask.sum()),
        "num_features": x_scaled.shape[1],
        "split_mode": cfg.split_mode,
    }

    _run_sanity_assertions(stats, cfg)

    logger.info(
        f"✅ گراف Elliptic ساخته شد: N={n:,} | E_final={edge_index.shape[1]:,} | "
        f"F={x_scaled.shape[1]} | pos_rate={stats['positive_rate']:.4f} | "
        f"train/val/test = {train_mask.sum()}/{val_mask.sum()}/{test_mask.sum()}"
    )
    return data


def get_or_build_cached_graph(cfg: DataConfig, seed: int = 42, force_rebuild: bool = False) -> Data:
    """
    کش‌گذاری گراف پیش‌پردازش‌شده روی دیسک (.pt) تا در ران‌های بعدی زمان
    بارگذاری/پیش‌پردازش (که برای Elliptic چند ثانیه است ولی در Colab با
    I/O کند می‌تواند آزاردهنده شود) صرفه‌جویی شود.
    """
    cache_dir = Path(cfg.cache_dir)
    cache_dir.mkdir(parents=True, exist_ok=True)
    cache_file = cache_dir / f"elliptic_graph_{cfg.split_mode}_seed{seed}.pt"

    if cache_file.exists() and not force_rebuild:
        logger.info(f"📦 بارگذاری گراف از کش: {cache_file}")
        return torch.load(cache_file, weights_only=False)

    data = load_elliptic_graph(cfg, seed=seed)
    torch.save(data, cache_file)
    logger.info(f"💾 گراف در کش ذخیره شد: {cache_file}")
    return data


# ==============================================================================
# لایهٔ سازگاری با قرارداد src/train.py
# ------------------------------------------------------------------------------
# train.py گردش کار دومرحله‌ای می‌خواهد (raw ⇒ preprocess). پیاده‌سازی واقعی
# این پروژه تک‌مرحله‌ای است: load_elliptic_graph تمام کارها (فیلتر، بازنمایه‌گذاری،
# ساخت edge_index، انتخاب ویژگی، ماسک زمانی، مقیاس‌دهی روی train) را انجام می‌دهد.
# این دو تابع فقط نگاشت نام‌اند و هیچ منطق علمی جدیدی اضافه نمی‌کنند.
# ==============================================================================
def load_elliptic_raw(cfg: DataConfig, seed: int = 42, force_rebuild: bool = False) -> Data:
    """گراف کامل و پیش‌پردازش‌شده (با کش). معادل get_or_build_cached_graph."""
    return get_or_build_cached_graph(cfg, seed=seed, force_rebuild=force_rebuild)


def preprocess_elliptic(data: Data, cfg: DataConfig = None, seed: int = 42) -> Data:
    """
    عبور شفاف: پیش‌پردازش پیش‌تر داخل load_elliptic_graph انجام شده است.
    این تابع فقط قرارداد فراخوانی train.py را برآورده می‌کند و به‌عمد
    هیچ تبدیل دومی روی داده اعمال نمی‌کند (جلوگیری از مقیاس‌دهی مضاعف).
    """
    for attr in ("x", "y", "edge_index", "train_mask", "val_mask", "test_mask"):
        assert hasattr(data, attr), f"[elliptic] گراف فاقد '{attr}' است."
    return data
