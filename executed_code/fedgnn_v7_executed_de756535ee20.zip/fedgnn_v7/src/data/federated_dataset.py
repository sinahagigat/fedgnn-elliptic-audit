# -*- coding: utf-8 -*-
"""
federated_dataset.py — ساخت زیرگراف کلاینت‌ها + ماسک‌ها + آمار مرزی
=====================================================================
این ماژول گراف سراسری + تخصیص پارتیشن را می‌گیرد و برای هر کلاینت یک
torch_geometric.data.Data مستقل (زیرگراف محلی) می‌سازد که مستقیماً به
src/fed/client.py (بلوک ۴) داده می‌شود.

نکات کلیدی:
  1) هر زیرگراف کلاینت شامل فقط یال‌های «درون‌کلاینتی» است (induced
     subgraph). یال‌های مرزی (بین دو کلاینت) در همین ماژول شمارش و به
     شکل «آمار گره‌های مرزی» استخراج می‌شوند تا در بلوک ۵ (VirtualNode)
     بدون افشای هویت داده، بین کلاینت‌ها هم‌ترازسازی شوند.
  2) اندیس‌های local↔global برای هر کلاینت نگه داشته می‌شود تا در تحلیل
     نهایی (مثلاً ساخت جدول per-client) قابل ردیابی باشد.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Dict, List, Tuple

import numpy as np
import torch
from torch_geometric.data import Data
from torch_geometric.utils import subgraph

from src.config import PartitionConfig, VirtualNodeConfig

logger = logging.getLogger("fedgnn.data.federated_dataset")


# ==============================================================================
# ساختار داده برای اطلاعات مرزی هر کلاینت
# ==============================================================================
@dataclass
class BoundaryInfo:
    """
    اطلاعات گره‌های مرزی یک کلاینت — یعنی گره‌هایی که حداقل یک یال به
    کلاینت دیگری دارند. این اطلاعات پایهٔ ساخت گره‌های مجازی (نوآوری ۲)
    در بلوک ۵ است.
    """
    local_boundary_idx: np.ndarray               # اندیس محلی گره‌های مرزی
    global_boundary_idx: np.ndarray               # اندیس سراسری متناظر
    neighbor_client_ids: Dict[int, List[int]] = field(default_factory=dict)
    # {اندیس محلی گره مرزی → لیست client_id های همسایهٔ خارجی}
    boundary_degree: np.ndarray = None            # تعداد یال خارجی هر گره مرزی


# ==============================================================================
# ساخت زیرگراف یک کلاینت
# ==============================================================================
def _build_client_subgraph(
    data: Data,
    assignment: np.ndarray,
    client_id: int,
) -> Tuple[Data, np.ndarray]:
    """
    استخراج زیرگراف القایی (induced subgraph) کلاینت client_id.

    Returns:
        (client_data, global_node_idx):
            client_data: Data مستقل با x, y, edge_index, masks محلی
            global_node_idx: [n_local] نگاشت اندیس محلی → اندیس سراسری
    """
    global_node_idx = np.where(assignment == client_id)[0]
    node_idx_t = torch.tensor(global_node_idx, dtype=torch.long)

    edge_index_local, _ = subgraph(
        node_idx_t,
        data.edge_index,
        relabel_nodes=True,
        num_nodes=data.num_nodes,
    )

    client_data = Data(
        x=data.x[node_idx_t].clone(),
        y=data.y[node_idx_t].clone(),
        edge_index=edge_index_local,
    )
    client_data.train_mask = data.train_mask[node_idx_t].clone()
    client_data.val_mask = data.val_mask[node_idx_t].clone()
    client_data.test_mask = data.test_mask[node_idx_t].clone()
    client_data.time_step = data.time_step[node_idx_t].clone()

    return client_data, global_node_idx


# ==============================================================================
# محاسبهٔ اطلاعات مرزی (بدون افشای داده خام)
# ==============================================================================
def _compute_boundary_info(
    data: Data,
    assignment: np.ndarray,
    client_id: int,
    global_node_idx: np.ndarray,
    global_to_local: Dict[int, int],
) -> BoundaryInfo:
    """
    شناسایی گره‌های مرزی کلاینت client_id: گره‌هایی که حداقل یک یال
    سراسری به گره‌ای در کلاینت دیگر دارند.

    مهم برای حریم خصوصی: در این تابع فقط شمارش/آمار محاسبه می‌شود —
    هیچ ویژگی خام گره همسایهٔ خارجی خوانده یا ذخیره نمی‌شود. آنچه بعداً
    مبادله می‌شود (در بلوک ۵) صرفاً آماره‌های تجمیعی (میانگین/واریانس)
    است، نه دادهٔ خام.
    """
    edge_index = data.edge_index.cpu().numpy()
    src, dst = edge_index[0], edge_index[1]

    client_node_set = set(global_node_idx.tolist())

    boundary_degree_map: Dict[int, int] = {}
    neighbor_client_map: Dict[int, set] = {}

    for s, d in zip(src, dst):
        s_in = s in client_node_set
        d_in = d in client_node_set
        if s_in and not d_in:
            boundary_degree_map[s] = boundary_degree_map.get(s, 0) + 1
            neighbor_client_map.setdefault(s, set()).add(int(assignment[d]))
        elif d_in and not s_in:
            boundary_degree_map[d] = boundary_degree_map.get(d, 0) + 1
            neighbor_client_map.setdefault(d, set()).add(int(assignment[s]))

    global_boundary_idx = np.array(sorted(boundary_degree_map.keys()), dtype=np.int64)
    local_boundary_idx = np.array(
        [global_to_local[g] for g in global_boundary_idx], dtype=np.int64
    )
    boundary_degree = np.array(
        [boundary_degree_map[g] for g in global_boundary_idx], dtype=np.int64
    )
    neighbor_client_ids = {
        global_to_local[g]: sorted(neighbor_client_map[g])
        for g in global_boundary_idx
    }

    return BoundaryInfo(
        local_boundary_idx=local_boundary_idx,
        global_boundary_idx=global_boundary_idx,
        neighbor_client_ids=neighbor_client_ids,
        boundary_degree=boundary_degree,
    )


# ==============================================================================
# ساخت کامل دیتاست فدرال (نقطهٔ ورود عمومی)
# ==============================================================================
@dataclass
class FederatedClientData:
    """بسته‌بندی کامل داده‌های یک کلاینت — ورودی مستقیم src/fed/client.py."""
    client_id: int
    data: Data
    global_node_idx: np.ndarray
    boundary_info: BoundaryInfo
    num_nodes: int
    num_edges: int
    num_train: int
    num_positives_train: int


def build_federated_dataset(
    data: Data,
    assignment: np.ndarray,
    partition_cfg: PartitionConfig,
) -> List[FederatedClientData]:
    """
    ساخت لیست کامل داده‌های فدرال برای همهٔ کلاینت‌ها.

    این تابع تنها نقطهٔ تلاقی بین خروجی partition.py و ورودی fed/client.py
    است؛ هرگونه تغییر در نحوهٔ نمایش داده باید فقط اینجا اعمال شود.
    """
    clients: List[FederatedClientData] = []

    for client_id in range(partition_cfg.num_clients):
        client_data, global_node_idx = _build_client_subgraph(data, assignment, client_id)

        if client_data.num_nodes == 0:
            logger.warning(f"⚠️ کلاینت {client_id} هیچ گره‌ای ندارد — از رجیستری حذف می‌شود.")
            continue

        global_to_local = {g: i for i, g in enumerate(global_node_idx)}
        boundary_info = _compute_boundary_info(
            data, assignment, client_id, global_node_idx, global_to_local
        )

        fcd = FederatedClientData(
            client_id=client_id,
            data=client_data,
            global_node_idx=global_node_idx,
            boundary_info=boundary_info,
            num_nodes=int(client_data.num_nodes),
            num_edges=int(client_data.edge_index.shape[1]),
            num_train=int(client_data.train_mask.sum().item()),
            num_positives_train=int(
                client_data.y[client_data.train_mask].sum().item()
            ),
        )
        clients.append(fcd)

        logger.info(
            f"👤 کلاینت {client_id}: n_nodes={fcd.num_nodes} | n_edges={fcd.num_edges} | "
            f"n_train={fcd.num_train} | n_pos_train={fcd.num_positives_train} | "
            f"n_boundary={len(boundary_info.local_boundary_idx)}"
        )

    total_boundary = sum(len(c.boundary_info.local_boundary_idx) for c in clients)
    logger.info(
        f"✅ دیتاست فدرال ساخته شد: {len(clients)} کلاینت فعال | "
        f"مجموع گره‌های مرزی (با شمارش تکراری بین کلاینت‌ها)={total_boundary}"
    )
    return clients


# ==============================================================================
# آمار تجمیعی مرزی برای گره‌های مجازی (رابط مستقیم به بلوک ۵)
# ==============================================================================
def compute_boundary_exchange_payload(
    client: FederatedClientData,
    virtual_cfg: VirtualNodeConfig,
) -> Dict[str, torch.Tensor]:
    """
    ساخت «بار مبادله‌ای» یک کلاینت برای هم‌ترازسازی گره‌های مجازی —
    دقیقاً طبق سیاست exchange_payload در VirtualNodeConfig.

    ⚠️ حریم خصوصی: خروجی این تابع فقط آماره‌های تجمیعی (میانگین/واریانس
    ویژگی گره‌های مرزی) است؛ هیچ بردار ویژگی خام یا شناسهٔ گره ارسال
    نمی‌شود. محافظت نویز/Secure-Agg در بلوک ۵ (src/fed/privacy.py) روی
    همین payload اعمال می‌شود.

    Args:
        client: بسته‌دادهٔ کلاینت (خروجی build_federated_dataset).
        virtual_cfg: تنظیمات گره مجازی.

    Returns:
        دیکشنری شامل حداقل 'mean' و در صورت نیاز 'var'، به‌همراه
        'boundary_degree' برای وزن‌دهی attach_policy در بلوک ۵.
    """
    bidx = client.boundary_info.local_boundary_idx
    if len(bidx) == 0:
        feat_dim = client.data.x.shape[1]
        zeros = torch.zeros(feat_dim)
        payload = {"mean": zeros, "boundary_degree": torch.tensor(0.0)}
        if virtual_cfg.exchange_payload == "mean_var":
            payload["var"] = zeros.clone()
        return payload

    x_boundary = client.data.x[bidx]  # [n_boundary, F]
    mean = x_boundary.mean(dim=0)

    payload: Dict[str, torch.Tensor] = {
        "mean": mean,
        "boundary_degree": torch.tensor(
            float(client.boundary_info.boundary_degree.sum())
        ),
    }

    if virtual_cfg.exchange_payload == "mean_var":
        var = x_boundary.var(dim=0, unbiased=False)
        payload["var"] = var
    elif virtual_cfg.exchange_payload == "sketch":
        # پروجکشن تصادفی ثابت (Johnson–Lindenstrauss سبک) برای کاهش ابعاد
        # پیش از مبادله — کاهش سربار ارتباطی بدون از دست دادن آمار کلی
        feat_dim = x_boundary.shape[1]
        rng = torch.Generator().manual_seed(client.client_id)
        proj = torch.randn(feat_dim, virtual_cfg.sketch_dim, generator=rng)
        proj = proj / (proj.norm(dim=0, keepdim=True) + 1e-8)
        payload["sketch"] = x_boundary.mean(dim=0) @ proj

    return payload


# ==============================================================================
# لایهٔ سازگاری با قرارداد src/train.py
# ==============================================================================
import copy as _copy
import torch as _torch


def build_federated_client_data(*args, **kw):
    """نام مورد انتظار train.py؛ واگذاری به build_federated_dataset."""
    return build_federated_dataset(*args, **kw)


def build_centralized_splits(full_data, seed: int = 42, cfg=None):
    """
    خط پایهٔ متمرکز: هیچ تقسیم کلاینتی انجام نمی‌شود و گراف کامل با همان
    ماسک‌های زمانیِ ساخته‌شده در elliptic.py برگردانده می‌شود.

    نکتهٔ مهم برای اعتبار مقاله: ماسک test در اینجا دقیقاً همان ماسکی است که
    build_global_test_split به واریانت‌های فدرال می‌دهد. بنابراین Centralized و
    FedGNN روی یک مجموعهٔ آزمونِ واحد سنجیده می‌شوند و مقایسه عادلانه است.
    """
    d = _copy.copy(full_data)
    for m in ("train_mask", "val_mask", "test_mask"):
        assert hasattr(d, m), f"[federated_dataset] ماسک '{m}' موجود نیست."
    assert int(d.test_mask.sum()) > 0, "[federated_dataset] مجموعهٔ test تهی است."
    return d


def build_global_test_split(full_data, cfg=None, seed: int = 42):
    """
    مجموعهٔ آزمون سراسری برای ارزیابی مدل global فدرال.

    گراف کامل (با همهٔ یال‌ها، از جمله یال‌های بین‌کلاینتی) برگردانده می‌شود و
    فقط ماسک test فعال است. دلیل: در زمان ارزیابی، سرور به توپولوژی کامل
    دسترسی دارد؛ محدودیت فدرال مربوط به فاز *آموزش* است، نه سنجش. اگر
    ارزیابی روی زیرگراف‌های بریدهٔ کلاینت‌ها انجام شود، همهٔ روش‌های فدرال
    به‌طور مصنوعی جریمه می‌شوند و مقایسه با Centralized بی‌اعتبار می‌گردد.
    """
    d = _copy.copy(full_data)
    assert hasattr(d, "test_mask"), "[federated_dataset] test_mask موجود نیست."
    n_test = int(d.test_mask.sum())
    n_pos = int(d.y[d.test_mask].sum())
    assert n_test > 0, "[federated_dataset] مجموعهٔ آزمون سراسری تهی است."
    assert n_pos > 0, (
        "[federated_dataset] مجموعهٔ آزمون سراسری هیچ نمونهٔ مثبتی ندارد؛ "
        "AP/F1 تعریف‌نشده می‌شود."
    )
    d.global_test_size = n_test
    d.global_test_positives = n_pos
    return d
