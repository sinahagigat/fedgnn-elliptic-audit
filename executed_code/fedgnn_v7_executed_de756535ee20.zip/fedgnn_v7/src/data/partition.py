# -*- coding: utf-8 -*-
"""
partition.py — پارتیشن‌بندی فدرال گراف بین کلاینت‌ها
========================================================
🔴 این ماژول مستقیماً پاسخ به مرگ‌آورترین ایراد نسخهٔ قبل است:

    «پارتیشن تصادفی گره با K=10 حفظ یال را به ≈۱۵.۶٪ کاهش می‌دهد و
     میانگین درجهٔ درون‌کلاینتی به ≈۰.۴۹ می‌رسد؛ در این رژیم پیام‌رسانی
     گرافی تقریباً بی‌اثر است و GNN عملاً به MLP تبدیل می‌شود.»

راه‌حل: پارتیشن پیش‌فرض مبتنی بر **جامعه (Louvain)** است که یال‌ها را تا
حد ممکن درون هر کلاینت نگه می‌دارد، به‌جای پاره کردن تصادفی گراف.
پارتیشن‌های "random_node" و "dirichlet_label" فقط برای مقایسهٔ حساسیت
(sensitivity analysis) در مقاله نگه داشته می‌شوند — دقیقاً برای اینکه
بتوان نشان داد چرا Louvain انتخاب شده است.
"""

from __future__ import annotations

import logging
from typing import Dict, List, Optional, Tuple

import networkx as nx
import numpy as np
import torch
from torch_geometric.data import Data

from src.config import PartitionConfig

logger = logging.getLogger("fedgnn.data.partition")


# ==============================================================================
# ابزار مشترک
# ==============================================================================
def _to_networkx_undirected(data: Data) -> nx.Graph:
    """ساخت nx.Graph سبک (فقط ساختار، بدون کپی ویژگی‌ها) برای تشخیص جامعه."""
    G = nx.Graph()
    G.add_nodes_from(range(data.num_nodes))
    edge_index = data.edge_index.cpu().numpy()
    edges = list(zip(edge_index[0].tolist(), edge_index[1].tolist()))
    G.add_edges_from(edges)
    return G


def _community_metric(nodes: List[int], data: Data, objective: str) -> float:
    """معیار اندازهٔ یک جامعه برای bin-packing، بر اساس balance_objective."""
    if objective == "nodes":
        return float(len(nodes))
    if objective == "positives":
        y = data.y.cpu().numpy()
        return float(y[nodes].sum())
    if objective == "edges":
        # تخمین سریع: مجموع درجهٔ گره‌ها (به‌جای شمارش دقیق یال درونی، برای سرعت)
        deg = torch.zeros(data.num_nodes, dtype=torch.long)
        deg.scatter_add_(0, data.edge_index[0], torch.ones(data.edge_index.shape[1], dtype=torch.long))
        return float(deg[nodes].sum().item())
    raise ValueError(f"balance_objective ناشناخته: {objective}")


def _greedy_bin_pack(
    communities: List[List[int]],
    num_clients: int,
    data: Data,
    objective: str,
) -> Dict[int, List[int]]:
    """
    Bin-packing حریص: جوامع را از بزرگ به کوچک مرتب کرده و هرکدام را به
    سبدی (کلاینت) که فعلاً کمترین بار دارد اضافه می‌کند. این استراتژی
    استاندارد LPT (Longest Processing Time first) است و انحراف نهایی از
    میانگین را محدود می‌کند.
    """
    community_sizes = [
        (_community_metric(c, data, objective), c) for c in communities
    ]
    community_sizes.sort(key=lambda t: t[0], reverse=True)

    bins: Dict[int, List[int]] = {k: [] for k in range(num_clients)}
    bin_loads = np.zeros(num_clients, dtype=np.float64)

    for size, community in community_sizes:
        target = int(np.argmin(bin_loads))
        bins[target].extend(community)
        bin_loads[target] += size

    return bins


def _assignment_from_bins(bins: Dict[int, List[int]], num_nodes: int) -> np.ndarray:
    assignment = np.full(num_nodes, -1, dtype=np.int64)
    for client_id, nodes in bins.items():
        assignment[nodes] = client_id
    if (assignment == -1).any():
        raise RuntimeError("❌ برخی گره‌ها به هیچ کلاینتی اختصاص نیافتند (باگ داخلی پارتیشن).")
    return assignment


# ==============================================================================
# ۱) اسکیم Louvain (پیش‌فرض)
# ==============================================================================
def _partition_louvain(data: Data, cfg: PartitionConfig, seed: int) -> np.ndarray:
    G = _to_networkx_undirected(data)
    communities = nx.algorithms.community.louvain_communities(
        G, resolution=cfg.louvain_resolution, seed=seed
    )
    communities = [list(c) for c in communities]
    logger.info(f"Louvain: {len(communities)} جامعه کشف شد (resolution={cfg.louvain_resolution}).")

    bins = _greedy_bin_pack(communities, cfg.num_clients, data, cfg.balance_objective)
    return _assignment_from_bins(bins, data.num_nodes)


# ==============================================================================
# ۲) اسکیم METIS (اختیاری با fallback خودکار)
# ==============================================================================
def _partition_metis(data: Data, cfg: PartitionConfig, seed: int) -> np.ndarray:
    try:
        import metis  # type: ignore
    except ImportError:
        logger.warning(
            "⚠️ کتابخانهٔ 'metis' نصب نیست؛ Graceful Degradation → بازگشت به Louvain."
        )
        return _partition_louvain(data, cfg, seed)

    G = _to_networkx_undirected(data)
    G.graph["node_weight_attr"] = None
    try:
        _, parts = metis.part_graph(G, nparts=cfg.num_clients, ufactor=cfg.metis_ufactor, seed=seed)
    except Exception as e:
        logger.warning(f"⚠️ اجرای METIS با خطا مواجه شد ({e})؛ بازگشت به Louvain.")
        return _partition_louvain(data, cfg, seed)

    return np.array(parts, dtype=np.int64)


# ==============================================================================
# ۳) اسکیم Random Node (baseline قدیمی — فقط برای sensitivity analysis)
# ==============================================================================
def _partition_random_node(data: Data, cfg: PartitionConfig, seed: int) -> np.ndarray:
    """
    ⚠️ این همان اسکیمی است که در نسخهٔ قبل باعث فروپاشی ساختار گراف شد.
    عمداً نگه داشته می‌شود تا در مقاله بتوان با اعداد نشان داد که چرا
    نباید استفاده شود (جدول Ablation روی partition.scheme).
    """
    rng = np.random.RandomState(seed)
    assignment = rng.randint(0, cfg.num_clients, size=data.num_nodes)
    return assignment.astype(np.int64)


# ==============================================================================
# ۴) اسکیم Dirichlet روی برچسب (non-IID شدید نوع label-skew)
# ==============================================================================
def _partition_dirichlet_label(data: Data, cfg: PartitionConfig, seed: int) -> np.ndarray:
    rng = np.random.RandomState(seed)
    y = data.y.cpu().numpy()
    assignment = np.full(data.num_nodes, -1, dtype=np.int64)

    for label in np.unique(y):
        idx = np.where(y == label)[0]
        rng.shuffle(idx)
        proportions = rng.dirichlet(alpha=[cfg.dirichlet_alpha] * cfg.num_clients)
        # اندیس‌های مرزی برش بر اساس تجمع نسبت‌ها
        cut_points = (np.cumsum(proportions) * len(idx)).astype(int)[:-1]
        splits = np.split(idx, cut_points)
        for client_id, split_idx in enumerate(splits):
            assignment[split_idx] = client_id

    return assignment


# ==============================================================================
# ۵) اسکیم Temporal Shard (تقسیم بر اساس بازهٔ زمانی — sensitivity دیگر)
# ==============================================================================
def _partition_temporal_shard(data: Data, cfg: PartitionConfig, seed: int) -> np.ndarray:
    time_step = data.time_step.cpu().numpy()
    unique_steps = np.sort(np.unique(time_step))
    shards = np.array_split(unique_steps, cfg.num_clients)
    step_to_client = {}
    for client_id, steps in enumerate(shards):
        for s in steps:
            step_to_client[int(s)] = client_id
    assignment = np.array([step_to_client[int(t)] for t in time_step], dtype=np.int64)
    return assignment


# ==============================================================================
# اجرای اسکیم انتخابی
# ==============================================================================
_SCHEME_DISPATch = {
    "louvain": _partition_louvain,
    "metis": _partition_metis,
    "random_node": _partition_random_node,
    "dirichlet_label": _partition_dirichlet_label,
    "temporal_shard": _partition_temporal_shard,
}


def _run_scheme(scheme: str, data: Data, cfg: PartitionConfig, seed: int) -> np.ndarray:
    if scheme not in _SCHEME_DISPATch:
        raise ValueError(f"partition.scheme ناشناخته: {scheme}")
    return _SCHEME_DISPATch[scheme](data, cfg, seed)


# ==============================================================================
# اصلاح تخصیص‌های نامعتبر (Reassignment)
# ==============================================================================
def _validate_and_fix(
    assignment: np.ndarray, data: Data, cfg: PartitionConfig, seed: int
) -> np.ndarray:
    """
    بررسی می‌کند که هر کلاینت حداقل min_nodes_per_client گره و
    min_positives_per_client_train گره مثبت در بخش train داشته باشد.
    در صورت نقض، گره از پرجمعیت‌ترین کلاینت به کم‌جمعیت‌ترین منتقل می‌شود.
    """
    rng = np.random.RandomState(seed + 999)
    y = data.y.cpu().numpy()
    train_mask = data.train_mask.cpu().numpy()

    for attempt in range(cfg.max_repartition_attempts):
        counts = np.bincount(assignment, minlength=cfg.num_clients)
        pos_counts = np.array([
            int(((assignment == k) & train_mask & (y == 1)).sum())
            for k in range(cfg.num_clients)
        ])

        violations = np.where(
            (counts < cfg.min_nodes_per_client) |
            (pos_counts < cfg.min_positives_per_client_train)
        )[0]

        if len(violations) == 0:
            logger.info(f"✓ تخصیص کلاینت‌ها معتبر است (تلاش {attempt}).")
            return assignment

        if not cfg.reassign_if_infeasible:
            logger.warning(
                f"⚠️ {len(violations)} کلاینت شرایط حداقلی را ندارند و "
                f"reassign_if_infeasible=False است؛ ادامه بدون اصلاح."
            )
            return assignment

        donor = int(np.argmax(counts))
        needy = int(violations[0])
        donor_nodes = np.where(assignment == donor)[0]

        # اگر کمبود از نوع 'مثبت' است، اولویت انتقال گره‌های مثبت است
        if pos_counts[needy] < cfg.min_positives_per_client_train:
            donor_pos_nodes = donor_nodes[
                (y[donor_nodes] == 1) & train_mask[donor_nodes]
            ]
            candidates = donor_pos_nodes if len(donor_pos_nodes) > 0 else donor_nodes
        else:
            candidates = donor_nodes

        n_move = min(
            max(cfg.min_nodes_per_client - counts[needy], 1),
            max(len(candidates) - cfg.min_nodes_per_client, 1),
        )
        n_move = max(1, min(n_move, len(candidates)))
        move_idx = rng.choice(candidates, size=n_move, replace=False)
        assignment[move_idx] = needy

    logger.warning(
        f"⚠️ پس از {cfg.max_repartition_attempts} تلاش، همهٔ محدودیت‌های حداقلی "
        f"برطرف نشدند. توزیع نهایی را در گزارش ثبت کنید (شفافیت برای داور)."
    )
    return assignment


# ==============================================================================
# محاسبهٔ آمار تشخیصی پارتیشن (برای مقاله و برای aggregation.py در بلوک ۴)
# ==============================================================================
def compute_partition_diagnostics(
    assignment: np.ndarray, data: Data, cfg: PartitionConfig
) -> Dict:
    """
    آمار کلیدی برای:
      (الف) جدول «کیفیت پارتیشن» در مقاله (edge retention, avg degree),
      (ب) وزن‌دهی کیفیت ساختار در AggregationConfig (نوآوری ۱).
    """
    edge_index = data.edge_index.cpu().numpy()
    src, dst = edge_index[0], edge_index[1]
    same_client = assignment[src] == assignment[dst]

    total_edges = len(src)
    intra_edges = int(same_client.sum())
    edge_retention_rate = intra_edges / max(total_edges, 1)

    per_client = {}
    y = data.y.cpu().numpy()
    train_mask = data.train_mask.cpu().numpy()

    for k in range(cfg.num_clients):
        node_mask = assignment == k
        n_nodes_k = int(node_mask.sum())
        edge_mask_k = same_client & (assignment[src] == k)
        n_edges_k = int(edge_mask_k.sum())
        avg_degree_k = (2 * n_edges_k) / max(n_nodes_k, 1)  # هر یال ۲ سر دارد

        n_pos_train_k = int((node_mask & train_mask & (y == 1)).sum())
        n_train_k = int((node_mask & train_mask).sum())
        local_pos_rate_k = n_pos_train_k / max(n_train_k, 1)

        per_client[k] = {
            "num_nodes": n_nodes_k,
            "num_intra_edges": n_edges_k,
            "avg_degree": avg_degree_k,
            "num_train": n_train_k,
            "num_positives_train": n_pos_train_k,
            "local_positive_rate": local_pos_rate_k,
        }

    sizes = np.array([v["num_nodes"] for v in per_client.values()], dtype=np.float64)
    imbalance_ratio = float(sizes.std() / max(sizes.mean(), 1e-9))

    diagnostics = {
        "scheme": cfg.scheme,
        "num_clients": cfg.num_clients,
        "total_edges_global": total_edges,
        "intra_client_edges": intra_edges,
        "edge_retention_rate": edge_retention_rate,
        "size_imbalance_ratio": imbalance_ratio,
        "per_client": per_client,
    }

    logger.info(
        f"📊 پارتیشن '{cfg.scheme}': edge_retention={edge_retention_rate:.3f} | "
        f"imbalance={imbalance_ratio:.3f} | "
        f"avg_degree_overall={np.mean([v['avg_degree'] for v in per_client.values()]):.3f}"
    )
    return diagnostics


def partition_graph(
    data: Data, cfg: PartitionConfig, seed: int
) -> Tuple[np.ndarray, Dict]:
    """
    نقطهٔ ورود اصلی پارتیشن‌بندی فدرال.

    مطابق درس گرفته‌شده از نسخهٔ قبل، این تابع:
      1) اسکیم انتخابی (پیش‌فرض: louvain) را اجرا می‌کند،
      2) تخصیص را نسبت به محدودیت‌های حداقلی (min_nodes/min_positives)
         اعتبارسنجی و در صورت نیاز اصلاح می‌کند،
      3) آمار تشخیصی کامل (edge retention, avg degree, imbalance) را
         محاسبه و همراه با assignment برمی‌گرداند تا هم در لاگ ران و هم
         در جدول مقاله مستقیماً قابل استفاده باشد.

    Args:
        data: گراف سراسری Elliptic (خروجی elliptic.load_elliptic_graph).
        cfg: تنظیمات پارتیشن (PartitionConfig).
        seed: seed این ران — اگر cfg.repartition_per_seed=True باشد،
            پارتیشن خودش هم یکی از منابع واریانس بین seed محسوب می‌شود
            (رویکردی صادقانه‌تر نسبت به ثابت نگه‌داشتن پارتیشن).

    Returns:
        (assignment, diagnostics):
            assignment: آرایهٔ [N] با مقادیر {0..num_clients-1}
            diagnostics: dict آمار کامل کیفیت پارتیشن
    """
    # v7: the fixed seed is configurable (v6a hard-coded 0).
    effective_seed = seed if cfg.repartition_per_seed else int(getattr(cfg, "fixed_partition_seed", 0))

    logger.info(
        f"🔧 شروع پارتیشن‌بندی | scheme={cfg.scheme} | "
        f"num_clients={cfg.num_clients} | seed={effective_seed} "
        f"(repartition_per_seed={cfg.repartition_per_seed})"
    )

    assignment = _run_scheme(cfg.scheme, data, cfg, effective_seed)
    assignment = _validate_and_fix(assignment, data, cfg, effective_seed)
    diagnostics = compute_partition_diagnostics(assignment, data, cfg)

    # ثبت seed مؤثر برای شفافیت کامل در artifact نهایی
    diagnostics["effective_partition_seed"] = effective_seed
    diagnostics["repartition_per_seed"] = cfg.repartition_per_seed

    return assignment, diagnostics


def run_partition_sensitivity(
    data: Data, cfg: PartitionConfig, seed: int
) -> Dict[str, Dict]:
    """
    اجرای چند اسکیم پارتیشن مختلف (طبق cfg.sensitivity_schemes) روی همان
    گراف و همان seed، برای تولید جدول مقایسه‌ای «حساسیت به نوع پارتیشن»
    در مقاله. این دقیقاً همان تحلیلی است که غیاب آن در نسخهٔ قبل باعث
    شد ایراد «پارتیشن تصادفی» اصلاً کشف نشود.

    Returns:
        دیکشنری {scheme_name: diagnostics} برای همهٔ اسکیم‌های درخواستی.
    """
    results: Dict[str, Dict] = {}
    original_scheme = cfg.scheme

    for scheme in cfg.sensitivity_schemes:
        cfg.scheme = scheme
        logger.info(f"📐 تحلیل حساسیت پارتیشن — اجرای اسکیم '{scheme}'...")
        assignment, diagnostics = partition_graph(data, cfg, seed)
        results[scheme] = diagnostics

    cfg.scheme = original_scheme  # بازگردانی تنظیمات اصلی — بدون side effect
    return results


# ==============================================================================
# لایهٔ سازگاری با قرارداد src/train.py
# ==============================================================================
def partition_graph_federated(data, cfg, seed: int = 42, **kw):
    """نام مورد انتظار train.py؛ مستقیماً به partition_graph واگذار می‌شود."""
    return partition_graph(data, cfg, seed, **kw)
