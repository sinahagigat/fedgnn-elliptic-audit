# -*- coding: utf-8 -*-
"""
main.py — نقطهٔ ورود اجرای کامل پروژه (تنها فایلی که مستقیماً اجرا می‌شود)
==============================================================================
جریان اجرا:
  1) پارس آرگومان‌های CLI (مسیر config، فعال/غیرفعال resume، مسیر خروجی)
  2) بارگذاری و اعتبارسنجی Config (fail-fast اگر config نامعتبر باشد)
  3) اجرای کامل ماتریس آزمایش‌ها از train.py (با resume-by-default)
  4) تولید گزارش نهایی از analyze.py (جدول‌ها + آزمون‌های آماری + LaTeX)
  5) چاپ خلاصهٔ نهایی قابل‌فهم برای انسان روی stdout

استفاده در Colab:
    !python main.py --config configs/main_config.yaml --output-dir /content/results
"""

from __future__ import annotations

import os
# v7: cuBLAS needs this before CUDA initialises for deterministic GEMMs.
os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")

import argparse
import logging
import sys
from pathlib import Path

from src.config import load_config
from src.train import run_all_experiments
from src.analyze import generate_full_report
from src.utils.common import ensure_dir


# ==============================================================================
# راه‌اندازی logging یکپارچه — همان فرمت در همهٔ ماژول‌ها
# ==============================================================================
def setup_logging(log_path: Path, verbose: bool = False) -> None:
    level = logging.DEBUG if verbose else logging.INFO
    formatter = logging.Formatter(
        fmt="%(asctime)s | %(name)s | %(levelname)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    root_logger = logging.getLogger("fedgnn")
    root_logger.setLevel(level)
    root_logger.handlers.clear()  # جلوگیری از تکرار handler در اجر

  # --- Handler کنسول (برای دیدن لاگ زنده در Colab) ---
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(formatter)
    root_logger.addHandler(console_handler)

    # --- Handler فایل (برای بازبینی بعدی، حتی اگر Colab قطع شود) ---
    log_path.parent.mkdir(parents=True, exist_ok=True)
    file_handler = logging.FileHandler(log_path, mode="a", encoding="utf-8")
    file_handler.setFormatter(formatter)
    root_logger.addHandler(file_handler)

    root_logger.info(f"📝 لاگینگ راه‌اندازی شد | سطح={logging.getLevelName(level)} | فایل={log_path}")


# ==============================================================================
# پارس آرگومان‌های CLI
# ==============================================================================
def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="FedGNN-Fraud v5.0.0 — اجرای کامل ماتریس آزمایش‌ها + تحلیل نهایی"
    )
    parser.add_argument(
        "--config", type=str, required=True,
        help="مسیر فایل YAML تنظیمات (مثلاً configs/main_config.yaml)",
    )
    parser.add_argument(
        "--output-dir", type=str, default="/content/results",
        help="مسیر ذخیرهٔ artifacts.json، لاگ‌ها و گزارش نهایی",
    )
    parser.add_argument(
        "--artifacts-name", type=str, default="artifacts.json",
        help="نام فایل artifacts (برای نگه‌داشتن نسخه‌های مختلف کنار هم)",
    )
    parser.add_argument(
        "--baseline", type=str, default="FedAvg_GCN",
        help="نام واریانتی که به‌عنوان baseline در مقایسه‌های آماری استفاده می‌شود",
    )
    parser.add_argument(
        "--skip-analysis", action="store_true",
        help="فقط ماتریس آزمایش‌ها را اجرا کن، تحلیل نهایی را رد کن (مفید برای resume سریع)",
    )
    parser.add_argument(
        "--seeds", type=str, default=None,
        help="v7: run only these seeds, e.g. '42-46' or '42,43,50'",
    )
    parser.add_argument(
        "--variants", type=str, default=None,
        help="v7: run only these variants, comma-separated names",
    )
    parser.add_argument(
        "--data-dir", type=str, default=None,
        help="v7: folder with the three Elliptic CSV files (overrides data.raw_dir; not part of the config hash)",
    )
    parser.add_argument(
        "--threads", type=int, default=None,
        help="v7: number of CPU threads for torch in this process",
    )
    parser.add_argument(
        "--verbose", action="store_true",
        help="فعال‌کردن لاگ سطح DEBUG (جزئیات کامل هر راند/کلاینت)",
    )
    return parser


# ==============================================================================
# تابع اصلی
# ==============================================================================
# --- نصب لایهٔ سازگاری نام‌های کانفیگ (باید پیش از ساخت Config اجرا شود) ---
from src.compat import install_config_compat, compat_report  # noqa: E402
import src.config as _fedgnn_config_module  # noqa: E402
install_config_compat(_fedgnn_config_module)


def _parse_seeds(text: str):
    """'42-46' -> [42..46]; '42,45,50' -> [42,45,50]; mixtures allowed."""
    out = []
    for part in text.split(","):
        part = part.strip()
        if "-" in part:
            a, b = part.split("-")
            out.extend(range(int(a), int(b) + 1))
        elif part:
            out.append(int(part))
    return out


def main() -> int:
    args = build_arg_parser().parse_args()
    output_dir = ensure_dir(Path(args.output_dir))
    artifacts_path = output_dir / args.artifacts_name

    setup_logging(log_path=output_dir / "run.log", verbose=args.verbose)
    logger = logging.getLogger("fedgnn.main")

    config_path = Path(args.config)
    assert config_path.exists(), f"❌ فایل config پیدا نشد: {config_path}"

    logger.info("=" * 70)
    logger.info("🚀 شروع اجرای FedGNN-Fraud v5.0.0")
    logger.info(f"📄 config: {config_path}")
    logger.info(f"💾 خروجی: {output_dir}")
    logger.info(f"📦 artifacts: {artifacts_path}")
    logger.info("=" * 70)

    try:
        cfg = load_config(config_path)
        if args.data_dir:
            # raw_dir and cache_dir are volatile paths: the config hash is unchanged
            cfg.data.raw_dir = str(Path(args.data_dir))
            cfg.data.cache_dir = str(Path(args.data_dir) / "cache")
        if args.threads:
            import torch
            torch.set_num_threads(int(args.threads))
            logger.info(f"torch threads = {torch.get_num_threads()}")
    except Exception as exc:
        logger.error(f"❌ خطا در بارگذاری/اعتبارسنجی config — اجرا متوقف شد (fail-fast): {exc}")
        return 1

    logger.info(
        f"📊 ماتریس آزمایش: {len(cfg.experiment.variants)} واریانت × "
        f"{len(cfg.experiment.seeds)} seed = "
        f"{len(cfg.experiment.variants) * len(cfg.experiment.seeds)} ران کل."
    )

    # --- مرحلهٔ ۱: اجرای کامل ماتریس آزمایش‌ها (resume-by-default) ---
    only_seeds = _parse_seeds(args.seeds) if args.seeds else None
    only_variants = [v.strip() for v in args.variants.split(",")] if args.variants else None
    if only_seeds or only_variants:
        logger.info(f"shard: seeds={only_seeds} variants={only_variants}")
    try:
        run_all_experiments(cfg, artifacts_path, only_seeds=only_seeds, only_variants=only_variants)
    except Exception as exc:
        logger.error(f"❌ خطای غیرمنتظره در حین اجرای ماتریس آزمایش‌ها: {exc}", exc_info=True)
        return 1

    if args.skip_analysis:
        logger.info("⏭️ تحلیل نهایی رد شد (--skip-analysis). اجرا با موفقیت پایان یافت.")
        return 0

    # --- مرحلهٔ ۲: تحلیل نهایی + تولید جدول‌ها/آزمون‌های آماری/LaTeX ---
    try:
        report = generate_full_report(
            artifacts_path=artifacts_path,
            output_dir=output_dir / "analysis",
            baseline_name=args.baseline,
        )
    except Exception as exc:
        logger.error(
            f"❌ خطا در مرحلهٔ تحلیل نهایی — اما artifacts.json کامل ذخیره شده "
            f"و می‌توان بعداً به‌صورت مجزا analyze.py را اجرا کرد: {exc}", exc_info=True
        )
        return 1

    # --- خلاصهٔ نهایی (مقاوم در برابر تفاوت نام کلیدها در analyze.py) ---
    logger.info("=" * 70)
    logger.info("🏁 اجرای کامل با موفقیت پایان یافت.")
    if isinstance(report, dict):
        logger.info(f"🔑 کلیدهای گزارش: {list(report.keys())}")
    df = report.get("summary_table") if isinstance(report, dict) else None
    if df is None and isinstance(report, dict):
        for k, v in report.items():
            if hasattr(v, "iterrows"):
                df = v
                break
    if df is not None and hasattr(df, "head"):
        logger.info("📋 جدول خلاصه (۳ ردیف اول):")
        for _, row in df.head(3).iterrows():
            logger.info("   • " + " | ".join(f"{c}={row[c]}" for c in df.columns))
    else:
        logger.warning("⚠️ جدول خلاصه یافت نشد — خروجی analyze.py را بررسی کنید.")
    stat = None
    if isinstance(report, dict):
        stat = report.get("statistical_comparison") or report.get("comparisons")
    if isinstance(stat, dict):
        sig = stat.get("significant_after_holm")
        logger.info(f"📈 معنادار پس از Holm (در برابر {args.baseline}): {sig or 'هیچ‌کدام'}")
    logger.info(f"📂 همهٔ خروجی‌ها در: {output_dir}")
    compat_report()
    logger.info("=" * 70)

    return 0


if __name__ == "__main__":
    sys.exit(main())
